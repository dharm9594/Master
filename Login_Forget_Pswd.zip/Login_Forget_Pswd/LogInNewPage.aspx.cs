﻿using System;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

public partial class LogInNewPage : System.Web.UI.Page
{
    DAL db = new DAL();
    BLL _bll = new BLL();
    BLL bal = new BLL();
    Hashtable hashparams = new Hashtable();
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Cache.SetNoStore();
        Response.Cache.SetCacheability(HttpCacheability.NoCache);

        // DecryptString("6d18301c7d9628d909069826c454758c","");
        if (!IsPostBack)
        {
            string antiforgerytoken = Guid.NewGuid().ToString();
            Session["AntiForgeryToken"] = antiforgerytoken;
            antiforgery.Value = antiforgerytoken.ToString();

            if (Request.Cookies["userid"] != null)

                txtUname.Text = Request.Cookies["userid"].Value;

            if (Request.Cookies["pwd"] != null)

                txtPwd.Attributes.Add("value", Request.Cookies["pwd"].Value);
            if (Request.Cookies["userid"] != null && Request.Cookies["pwd"] != null)
                ChkboxRememberMe.Checked = true;
        }
        else
        {
            if (Session["AntiForgeryToken"] != null)
            {
                string stored = Session["AntiForgeryToken"].ToString();
                string sent = antiforgery.Value;
                if (sent != stored)
                {
                    Response.Redirect("LogInNewPage.aspx");
                }
            }
            else
            {
                Response.Redirect("LogInNewPage.aspx");
            }
        }
    }


   
    private string md5(string password)
    {
        System.Security.Cryptography.MD5CryptoServiceProvider x = new System.Security.Cryptography.MD5CryptoServiceProvider();
        byte[] bs = System.Text.Encoding.UTF8.GetBytes(password);
        bs = x.ComputeHash(bs);
        System.Text.StringBuilder s = new System.Text.StringBuilder();
        foreach (byte b in bs)
        {
            s.Append(b.ToString("x2").ToLower());
        }
        return s.ToString();
    }
    public static string DecryptString(string Message, string Passphrase)
    {
        byte[] Results;
        System.Text.UTF8Encoding UTF8 = new System.Text.UTF8Encoding();

        // Step 1. We hash the passphrase using MD5
        // We use the MD5 hash generator as the result is a 128 bit byte array
        // which is a valid length for the TripleDES encoder we use below

        MD5CryptoServiceProvider HashProvider = new MD5CryptoServiceProvider();
        byte[] TDESKey = HashProvider.ComputeHash(UTF8.GetBytes(Passphrase));

        // Step 2. Create a new TripleDESCryptoServiceProvider object
        TripleDESCryptoServiceProvider TDESAlgorithm = new TripleDESCryptoServiceProvider();

        // Step 3. Setup the decoder
        TDESAlgorithm.Key = TDESKey;
        TDESAlgorithm.Mode = CipherMode.ECB;
        TDESAlgorithm.Padding = PaddingMode.PKCS7;

        // Step 4. Convert the input string to a byte[]
        byte[] DataToDecrypt = Convert.FromBase64String(Message);

        // Step 5. Attempt to decrypt the string
        try
        {
            ICryptoTransform Decryptor = TDESAlgorithm.CreateDecryptor();
            Results = Decryptor.TransformFinalBlock(DataToDecrypt, 0, DataToDecrypt.Length);
        }
        finally
        {
            // Clear the TripleDes and Hashprovider services of any sensitive information
            TDESAlgorithm.Clear();
            HashProvider.Clear();
        }

        // Step 6. Return the decrypted string in UTF8 format
        return UTF8.GetString(Results);
    }

    public static class SHA
    {

        public static string GenerateSHA256String(string inputString)
        {
            SHA256 sha256 = SHA256Managed.Create();
            byte[] bytes = Encoding.UTF8.GetBytes(inputString);
            byte[] hash = sha256.ComputeHash(bytes);
            return GetStringFromHash(hash);
        }

        public static string GenerateSHA512String(string inputString)
        {
            SHA512 sha512 = SHA512Managed.Create();
            byte[] bytes = Encoding.UTF8.GetBytes(inputString);
            byte[] hash = sha512.ComputeHash(bytes);
            return GetStringFromHash(hash);
        }

        private static string GetStringFromHash(byte[] hash)
        {
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                result.Append(hash[i].ToString("X2"));
            }
            return result.ToString();
        }

    }
    protected void btnLogin_Click1(object sender, EventArgs e)
    {
        try
        {
            if (txtUname.Text != "" && txtPwd.Text != "")
            {
                _bll.UserName = Convert.ToString(txtUname.Text);
                _bll.password = Convert.ToString(txtPwd.Text);

                //_bll.password = md5(_bll.password);



                _bll.password = SHA.GenerateSHA256String(_bll.password);

                DataTable dt = new DataTable();



                hashparams.Add("@UserName", _bll.UserName);
                hashparams.Add("@userpass", _bll.password);
                _bll = new BLL();
                _bll.GetDataTable("Usp_get_Login_Access", hashparams, CommandType.StoredProcedure, out dt);

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        if (Convert.ToString(row["ERROR"]) == "0")
                        {
                            if (ChkboxRememberMe.Checked == true)
                            {
                                Response.Cookies["userid"].Value = txtUname.Text;
                                Response.Cookies["pwd"].Value = txtPwd.Text;
                                Response.Cookies["userid"].Expires = DateTime.Now.AddDays(15);
                                Response.Cookies["pwd"].Expires = DateTime.Now.AddDays(15);
                            }

                            else

                            {

                                Response.Cookies["userid"].Expires = DateTime.Now.AddDays(-1);

                                Response.Cookies["pwd"].Expires = DateTime.Now.AddDays(-1);

                            }


                            Session["iUser"] = Convert.ToString(row["iUser"]);

                            Session["DisplayName"] = Convert.ToString(row["UserName"]);
                            Session["UserRole"] = Convert.ToString(row["UserRole"]);
                            Session["LastLogin"] = Convert.ToString(row["LastLogin"]);
                            Session["isPageAccess"] = Convert.ToString(row["isPageAccess"]);
                            Session["isBank"] = Convert.ToString(row["isBank"]);
                            Session["IpAddress"] = HttpContext.Current.Request.UserHostAddress;


                            string guid = Guid.NewGuid().ToString();
                            HttpContext.Current.Session["AuthToken"] = guid;
                            if (HttpContext.Current.Request.Cookies["ASP.NET_SessionId"] != null)
                            {
                                HttpContext.Current.Session["ASPSession"] = HttpContext.Current.Request.Cookies["ASP.NET_SessionId"].Value;
                            }

                            HttpCookie cookie = new HttpCookie("MPor_AuthToken", guid);
                            cookie.Expires = DateTime.Now.AddHours(8);
                            cookie.HttpOnly = true;

                            if (Request.IsSecureConnection)
                            {
                                cookie.Secure = true;
                            }
                            Response.Cookies.Add(cookie);


                            if (Convert.ToString(row["isPageAccess"]) == "1")
                            {
                                Response.Redirect("Dashboard.aspx");
                            }
                            else
                            {
                                Response.Redirect("Home.aspx");
                            }

                        }
                        else if (Convert.ToString(row["ERROR"]) == "2")
                        {
                            Session["DisplayName"] = Convert.ToString(row["UserName"]);

                            string errMsg = Convert.ToString(row["ErrMsg"]);

                            MessageBox.Show(errMsg);
                            Response.Redirect("ChangePassword.aspx");

                        }
                        else if (Convert.ToString(row["ERROR"]) == "1")
                        {

                            MessageBox.Show(Convert.ToString(row["ErrMsg"]));

                        }
                        else if (Convert.ToString(row["ERROR"]) == "99")
                        {

                            MessageBox.Show(Convert.ToString(row["ErrMsg"]));

                        }

                    }
                }

            }


        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message.ToString());
        }
    }

    protected void btnSubmitClick(object sender, EventArgs e)
    {

        if (txtUserName.Text != "" && txtEmailId.Text != "")
        {
            string UserName = Convert.ToString(txtUserName.Text);
            string EmailID = Convert.ToString(txtEmailId.Text);
            DataTable dt = new DataTable();
            Hashtable @params = new Hashtable();
            @params.Add("@UserName", UserName);
            @params.Add("@EMailID", EmailID);

            bal.GetDataTable("Usp_Update_Random_Password_for_User", @params, CommandType.StoredProcedure, out dt);
            if (dt.Rows.Count > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "DispMsg", "alert('" + Convert.ToString(dt.Rows[0]["Err"]) + "');", true);
                dt.Dispose();
            }
            //Thread.Sleep()
            // Response.Redirect("LogInNewPage.aspx");

        }
    }

   
}