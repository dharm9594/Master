﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Text;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

/// <summary>
/// Summary description for DAL
/// </summary>
public class DAL
{
    SqlConnection con = null;
    string output = null;
    DataTable dt = new DataTable();
    SqlCommand cmd;
    SqlDataAdapter da = new SqlDataAdapter();
    DataSet ds = new DataSet();
    public static string Base64Encode(string plainText)
    {
        var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
        return System.Convert.ToBase64String(plainTextBytes);
    }

    public static string Base64Decode(string base64EncodedData)
    {
        var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
        return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
    }

    #region Reusable
    public DataTable setDefaults(string spname, string[] parameters, object[] values)
    {
        cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = spname;
        cmd.Connection = con;
        cmd.CommandTimeout = 600000;
        for (int i = 0; i < parameters.Length; i++)
        {
            cmd.Parameters.AddWithValue(parameters[i], values[i].ToString());
        }
        fillDT();
        return dt;
    }
    void conOpen()
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
    }
    void conClose()
    {
        if (con.State == ConnectionState.Open)
            con.Close();
    }
    void executeNonQuery()
    {
        conOpen();
        cmd.ExecuteNonQuery();
        conClose();
    }
    void fillDT()
    {
        dt = new DataTable();
        da = new SqlDataAdapter(cmd);
        conOpen();
        da.Fill(dt);
        conClose();
    }
    void fillDS()
    {
        ds = new DataSet();
        da = new SqlDataAdapter(cmd);
        conOpen();
        da.Fill(ds);
        conClose();
    }

    #endregion


    public DataTable GetValue(string spname, string table)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        using (SqlConnection connect = new SqlConnection(Base64Decode(_connectionstring)))
        {
            try
            {
                //con = new SqlConnection(DAL.Base64Decode(_connectionstring));
                SqlCommand cmd = new SqlCommand(spname, connect);
                cmd.CommandType = CommandType.StoredProcedure;
		cmd.CommandTimeout=300;
                cmd.Parameters.AddWithValue("@UploadFile", table);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
            }
            finally
            {
                if (connect != null)
                    ((IDisposable)connect).Dispose();
            }
        }
        return dt;
    }
 public DataTable Usp_Insert_TollFareMapping(string PlazaCode, int AVC, int vehicle_class, string username)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("usp_insert_tollFareMapping", con);
        cmd.Parameters.AddWithValue("@toll_id", PlazaCode);
        cmd.Parameters.AddWithValue("@avc_id", AVC);
        cmd.Parameters.AddWithValue("@vc_etc", vehicle_class);

        cmd.Parameters.AddWithValue("@Inserted_By", username);
        
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }
public DataTable Usp_Toll_Congiguration_Fare_Master(string Toll_Id, string AVC, string Journey_Type, string TripCount, string Trip_Type, string Is_Active, string Start_Date, string End_Date, int Fare)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Toll_Congiguration_Fare_Master", con);

        cmd.Parameters.AddWithValue("@Toll_Id", Toll_Id);
        cmd.Parameters.AddWithValue("@AVC", AVC);
        cmd.Parameters.AddWithValue("@Journey_Type", Journey_Type);
        cmd.Parameters.AddWithValue("@Trip_Count", TripCount);
        cmd.Parameters.AddWithValue("@Trip_Type", Trip_Type);
        
        cmd.Parameters.AddWithValue("@Is_Active", Is_Active);
        cmd.Parameters.AddWithValue("@Start_Date", Start_Date);
        cmd.Parameters.AddWithValue("@End_Date", End_Date);
        cmd.Parameters.AddWithValue("@Fare", Fare);

        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }
public DataTable Usp_Get_tollFareMapping(string plazaCode)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("usp_Get_tollFareMapping", con);
        cmd.Parameters.AddWithValue("@toll_id", plazaCode);
        
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

 public DataTable Usp_Toll_Congiguration_Get_Fare_Master(string plazaCode)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Toll_Congiguration_Get_Fare_Master", con);
        cmd.Parameters.AddWithValue("@toll_id", plazaCode);

        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }
 public DataTable USP_EditDelete_TollFareMapping(string flag, int iFare, string PlazaCode, int AVC, int vehicle_class, string username, int VehicleGroupID)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("usp_editDelete_tollFareMapping", con);
        cmd.Parameters.AddWithValue("@Flag", flag);
        cmd.Parameters.AddWithValue("@iFare", iFare);
        cmd.Parameters.AddWithValue("@toll_id", PlazaCode);
        cmd.Parameters.AddWithValue("@avc_id", AVC);
        cmd.Parameters.AddWithValue("@vc_etc", vehicle_class);
        cmd.Parameters.AddWithValue("@Inserted_By", username);
        cmd.Parameters.AddWithValue("@VehicleGroupID", VehicleGroupID);
       
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

public DataTable Usp_insert_TollConfig_LaneDetails(string Toll_id, string LaneId, string LaneDescrptn, string LaneDirectn, string LaneType, string LaneIsActive)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("usp_insert_TollConfig_LaneDetails", con);
        cmd.Parameters.AddWithValue("@Toll_id", Toll_id);
        cmd.Parameters.AddWithValue("@LaneId", LaneId);
        cmd.Parameters.AddWithValue("@LaneDescrptn", LaneDescrptn);
        cmd.Parameters.AddWithValue("@LaneDirectn", LaneDirectn);
        cmd.Parameters.AddWithValue("@LaneType", LaneType);
        cmd.Parameters.AddWithValue("@LaneIsActive", LaneIsActive);
        
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

public DataTable USP_EditDelete_TollConfig_Lane(string flag,int ID, string Toll_id, string LaneId, string LaneDescrptn, string LaneDirectn, string LaneType, string LaneIsActive)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("usp_EditDelete_TollConfig_Lane", con);
        cmd.Parameters.AddWithValue("@Flag", flag);
        cmd.Parameters.AddWithValue("@ID", ID);
        cmd.Parameters.AddWithValue("@Toll_id", Toll_id);
        cmd.Parameters.AddWithValue("@LaneId", LaneId);
        cmd.Parameters.AddWithValue("@LaneDescrptn", LaneDescrptn);
        cmd.Parameters.AddWithValue("@LaneDirectn", LaneDirectn);
        cmd.Parameters.AddWithValue("@LaneType", LaneType);
        cmd.Parameters.AddWithValue("@LaneIsActive", LaneIsActive);
        
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

public DataTable Usp_Get_TollConfig_LaneDetails(string plazaCode)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("usp_Get_TollConfig_LaneDetails", con);
        cmd.Parameters.AddWithValue("@toll_id", plazaCode);

        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }
  public DataTable Usp_Toll_Congiguration_Get_Fare_Master_Update_Delete(string flag,int iFare, string Toll_Id, string AVC, string Journey_Type, string TripCount, string Trip_Type, string Is_Active, string Start_Date, string End_Date,int Fare)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Toll_Congiguration_Get_Fare_Master_Update_Delete", con);
        cmd.Parameters.AddWithValue("@Flag", flag);
        cmd.Parameters.AddWithValue("@iFare", iFare);
        cmd.Parameters.AddWithValue("@Toll_Id", Toll_Id);
        cmd.Parameters.AddWithValue("@AVC", AVC);
        cmd.Parameters.AddWithValue("@Journey_Type", Journey_Type);
        cmd.Parameters.AddWithValue("@Trip_Count", TripCount);
        cmd.Parameters.AddWithValue("@Trip_Type", Trip_Type);
        cmd.Parameters.AddWithValue("@Is_Active", Is_Active);
        cmd.Parameters.AddWithValue("@Start_Date", Start_Date);
        cmd.Parameters.AddWithValue("@End_Date", End_Date);
        cmd.Parameters.AddWithValue("@Fare", Fare);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_User_Status()
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_User_Status", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }



    public DataTable Usp_Response()
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Response", con);
        cmd.CommandType = CommandType.StoredProcedure;
        dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }


    public DataTable Usp_UpdateFailureStatus(string Reason, string MerchantId)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_UpdateFailureStatus", con);
        cmd.Parameters.AddWithValue("@Reason", Reason);
        cmd.Parameters.AddWithValue("@MerchantId", MerchantId);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }
 public DataTable usp_get_userdetails(string User,string Search)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("usp_get_userdetails", con);
        cmd.CommandType = CommandType.StoredProcedure;
	    cmd.Parameters.AddWithValue("@iUser", User);
        cmd.Parameters.AddWithValue("@search", Search);
        dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }
    public DataTable InsertDecryptedData(string data)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Insert_DecryptedData", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Data", data);
        dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }


   public DataTable usp_get_userdetails(string User)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("usp_get_userdetails", con);
        cmd.CommandType = CommandType.StoredProcedure;
	cmd.Parameters.AddWithValue("@iUser", User);
        dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_InsertResponseFromNPCI(string doc, string MerchantOrderID, string tag, string VehRegNo)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd1 = new SqlCommand("Usp_InsertResponseFromNPCI", con);
        dt = new DataTable();
        cmd1.CommandType = CommandType.StoredProcedure;
        cmd1.Parameters.AddWithValue("@doc", doc);
        cmd1.Parameters.AddWithValue("@MerchantOrderId", MerchantOrderID);
        cmd1.Parameters.AddWithValue("@TagId", tag);
        cmd1.Parameters.AddWithValue("@VehRegNo", VehRegNo);
        SqlDataAdapter da = new SqlDataAdapter(cmd1);
        da.Fill(dt);
        return dt;

    }

 public DataTable usp_insertUpdate_userDetails(int flag, string IpAddress,string userid,string username,string pass,string mobile,string email,string tollid,string emailcc,string isactive,string userroll,string updatedby,string action,string strPageAccess,string iUser,string IsBank)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("usp_insertUpdate_userDetails", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@flag", flag);
        cmd.Parameters.AddWithValue("@LoginName", userid);
        cmd.Parameters.AddWithValue("@LoginPass", pass);
        cmd.Parameters.AddWithValue("@Toll_ID", tollid);
        cmd.Parameters.AddWithValue("@DisplayName", username);
        cmd.Parameters.AddWithValue("@EmailID", email);
        cmd.Parameters.AddWithValue("@MobileNo", mobile);
        cmd.Parameters.AddWithValue("@EmailCC", emailcc);
        cmd.Parameters.AddWithValue("@isActive", isactive);
        cmd.Parameters.AddWithValue("@UserRole", userroll);
        cmd.Parameters.AddWithValue("@LoggedIn_iUser", updatedby);
        cmd.Parameters.AddWithValue("@action",action);
        cmd.Parameters.AddWithValue("@iPageList", strPageAccess);
 	    cmd.Parameters.AddWithValue("@User", iUser);
        cmd.Parameters.AddWithValue("@IsBank", IsBank);
        cmd.Parameters.AddWithValue("@IpAddress", IpAddress);


        dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_Request_SearchByTag_SBIePay(string TagId, string VRN)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Request_SearchByTag_SBIePay", con);
        cmd.Parameters.AddWithValue("@TagID", TagId);
        cmd.Parameters.AddWithValue("@VRN", VRN);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

   public DataTable Usp_insert_TollBankDetails(string Toll_id,string bank_type, string Account_No,string Account_Name,string acc_type,string ifsc_code,string frmdate,string todate,string username,int iFlag)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("usp_insert_tollBankDetails", con);
        cmd.Parameters.AddWithValue("@Toll_id", Toll_id);
        cmd.Parameters.AddWithValue("@Bank_Type", bank_type);
        cmd.Parameters.AddWithValue("@Account_No", Account_No);
        cmd.Parameters.AddWithValue("@Account_Name", Account_Name);
        cmd.Parameters.AddWithValue("@Account_Type", acc_type);
        cmd.Parameters.AddWithValue("@IFSC_Code", ifsc_code);
        cmd.Parameters.AddWithValue("@Start_Date", frmdate);
        cmd.Parameters.AddWithValue("@End_Date", todate);
        cmd.Parameters.AddWithValue("@inserted_by", username);
        cmd.Parameters.AddWithValue("@Agency_Name", username);
        cmd.Parameters.AddWithValue("@iFlag", iFlag);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_Get_TollBankDetails(string Status, string from, string to, string User,string isBank)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("usp_Get_tollBankDetails", con);
        cmd.Parameters.AddWithValue("@Status", Status);
        cmd.Parameters.AddWithValue("@from", from);
        cmd.Parameters.AddWithValue("@to", to);
        cmd.Parameters.AddWithValue("@User", User);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }
    public DataTable USP_ApprReject_BankDetails(string ID,string ReasonDesc, int Approve_Status, string User)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("USP_ApprReject_BankDetails", con);
        cmd.Parameters.AddWithValue("@ID", ID);
        cmd.Parameters.AddWithValue("@Approve_Status", Approve_Status);
        cmd.Parameters.AddWithValue("@ReasonDesc", ReasonDesc);
        cmd.Parameters.AddWithValue("@User", User);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable USP_EditDelete_BankDetails(string flag,string ID, string  bank_type, string AccountNo, string Account_Name,string Account_type,string ifsc_code,string start_date,string end_date,string user)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("USP_EditDelete_BankDetails", con);
        cmd.Parameters.AddWithValue("@Flag", flag);
        cmd.Parameters.AddWithValue("@ID", ID);
        cmd.Parameters.AddWithValue("@Bank_Type", bank_type);
        cmd.Parameters.AddWithValue("@Account_No", AccountNo);
        cmd.Parameters.AddWithValue("@Account_Name", Account_Name);
        cmd.Parameters.AddWithValue("@Account_Type", Account_type);
        cmd.Parameters.AddWithValue("@IFSC_Code", ifsc_code);
        cmd.Parameters.AddWithValue("@Start_Date", start_date);
        cmd.Parameters.AddWithValue("@End_Date", end_date);
        cmd.Parameters.AddWithValue("@Updated_by", user);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }


    public DataTable Usp_Identityid_Monthly_Blacklist(string tag, string VehRegNo)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Identityid_Monthly_Blacklist", con);
        dt = new DataTable();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@tagid", tag);
        cmd.Parameters.AddWithValue("@VehicleRegNo", VehRegNo);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }
    public DataTable Usp_Request_Pay_SBIePay_EPaySubmit(string tag, string VehRegNo, string MrechantOrderID, string TagStatus, string CCHVechicle, string TripType, string NoOfJou, string PriceTy, string Amount, string fromdate, string todate, string tollid, string Descrip, string tollname, string ClickStatus, string RequestTime, string BankName, string IssueDate, string ExcCode)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        dt = new DataTable();
        try
        {

            con = new SqlConnection(DAL.Base64Decode(_connectionstring));
            SqlCommand cmd = new SqlCommand("Usp_Request_Pay_SBIePay_ETCSubmit", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@TagID", tag);
            cmd.Parameters.AddWithValue("@vehRegNo", VehRegNo);
            cmd.Parameters.AddWithValue("@TagStatus", TagStatus);
            cmd.Parameters.AddWithValue("@CCHVechile", CCHVechicle);
            cmd.Parameters.AddWithValue("@TripType", TripType);
            cmd.Parameters.AddWithValue("@NumberofJou", NoOfJou);
            cmd.Parameters.AddWithValue("@PriceTy", PriceTy);
            cmd.Parameters.AddWithValue("@Amount", Amount);
            cmd.Parameters.AddWithValue("@MerchantOrderId", MrechantOrderID);
            cmd.Parameters.AddWithValue("@FromDate", fromdate);
            cmd.Parameters.AddWithValue("@ToDate", todate);
            cmd.Parameters.AddWithValue("@Tollname", tollname);
            cmd.Parameters.AddWithValue("@Descrip", Descrip);
            cmd.Parameters.AddWithValue("@toll_id", tollid);
            cmd.Parameters.AddWithValue("@ClickStatus", ClickStatus);
            cmd.Parameters.AddWithValue("@RequestTime", RequestTime);
            cmd.Parameters.AddWithValue("@BankName", BankName);
            cmd.Parameters.AddWithValue("@IssueDate", IssueDate);
            cmd.Parameters.AddWithValue("@ExcCode", ExcCode);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();



        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message.ToString());
        }
        return dt;
    }

    public DataTable Usp_Request_Search_SBIePay(string MrechantOrderID)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Request_Search_SBIePay", con);

        cmd.Parameters.AddWithValue("@MerchantOrderId", MrechantOrderID);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_InsertDoubleVerification(string SBIRefrenceNo, string SBIStatus, string Country, string Currency, string otherDetails, string MrechantOrderID, string Amount, string Message, string gatewayCode, string traceNumber, string InstructionDate, string PayMode, string CIN)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        dt = new DataTable();
        try
        {

            con = new SqlConnection(DAL.Base64Decode(_connectionstring));
            SqlCommand cmd = new SqlCommand("Usp_InsertDoubleVerification", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Atrn", SBIRefrenceNo);
            cmd.Parameters.AddWithValue("@Status", SBIStatus);
            cmd.Parameters.AddWithValue("@Country", Country);
            cmd.Parameters.AddWithValue("@Currency", Currency);
            cmd.Parameters.AddWithValue("@OtherDetails", otherDetails);
            cmd.Parameters.AddWithValue("@MerchantOrderNo", MrechantOrderID);
            cmd.Parameters.AddWithValue("@Amount", Amount);
            cmd.Parameters.AddWithValue("@Message", Message);
            cmd.Parameters.AddWithValue("@GateWayCode", gatewayCode);
            cmd.Parameters.AddWithValue("@TraceNo", traceNumber);
            cmd.Parameters.AddWithValue("@InstructionDate", InstructionDate);
            cmd.Parameters.AddWithValue("@Paymode", PayMode);
            cmd.Parameters.AddWithValue("@CIN", CIN);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            con.Dispose();

        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message.ToString());
        }
        return dt;
    }

    public DataTable Usp_Identityid_Monthly_SBIePay(string tag, string VehRegNo, string OrderId)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Identityid_Monthly_SBIePay", con);
        dt = new DataTable();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@tagid", tag);
        cmd.Parameters.AddWithValue("@VehicleRegNo", VehRegNo);
        cmd.Parameters.AddWithValue("@MerchantOrderId", OrderId);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_CheckTagExsist(string tollid, string tagid, string VehRegNo, string FromDate)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_CheckTagExsist", con);
        dt = new DataTable();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Toll_id", tollid);
        cmd.Parameters.AddWithValue("@TagID", tagid);
        cmd.Parameters.AddWithValue("@VehRegNo", VehRegNo);
        cmd.Parameters.AddWithValue("@EffectiveDate", FromDate);
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        con.Close();
        con.Dispose();
        return dt;
    }


    public DataTable Usp_PlazaName()
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_PlazaName", con);
        cmd.CommandType = CommandType.StoredProcedure;
        dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_GetBankName(string BankCode)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_GetBankName", con);
        dt = new DataTable();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@BankCode", BankCode);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_MonthlyPass_type()
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_MonthlyPass_type", con);
        cmd.CommandType = CommandType.StoredProcedure;
        dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_LocalPass_type(string User)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_LocalPass_type", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@User", User);
        dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }


    public DataTable Usp_LocalNonCommercial_type()
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_LocalNonCommercial_type", con);
        cmd.CommandType = CommandType.StoredProcedure;
        dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_LocalNonCommercial_Amount()
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_LocalNonCommercial_Amount", con);
        cmd.CommandType = CommandType.StoredProcedure;
        dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }
    public DataTable Usp_Identityid_Monthly(string tag)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Identityid_Monthly", con);
        dt = new DataTable();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@tagid", tag);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_Identityid_Monthly_SBIePay(string tag)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Identityid_Monthly_SBIePay", con);
        dt = new DataTable();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@tagid", tag);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }


    public DataTable Usp_Expiry_Date(string From)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Expiry_Date", con);
        dt = new DataTable();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@From", From);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataSet Usp_Fare_Toll(string user, string Vechicleclass)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Fare_Toll", con);
        ds = new DataSet();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@User", user);
        cmd.Parameters.AddWithValue("@VechicleClass", Vechicleclass);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        return ds;
    }

    public DataSet Usp_Fare_Toll_For_SBIepay(string tollid, string Vechicleclass)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Fare_Toll_For_SBIepay", con);
        ds = new DataSet();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@tollid", tollid);
        cmd.Parameters.AddWithValue("@VechicleClass", Vechicleclass);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        return ds;
    }

    public DataSet Usp_Fare_Toll_For_AllPassType(string PassType, string tollid, string Vechicleclass)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Fare_Toll_For_AllPassType", con);
        ds = new DataSet();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@PassType", PassType);
        cmd.Parameters.AddWithValue("@tollid", tollid);
        cmd.Parameters.AddWithValue("@VechicleClass", Vechicleclass);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        return ds;
    }

    public DataSet Usp_Fare_Toll_For_LocalPass(string user, string Vechicleclass)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Fare_Toll_For_LocalPass", con);
        ds = new DataSet();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@User", user);
        cmd.Parameters.AddWithValue("@VechicleClass", Vechicleclass);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        return ds;
    }

    public DataSet Usp_Fare_Toll_For_LocalNonCommercial(string user, string Vechicleclass)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Fare_Toll_LocalNonCommercial", con);
        ds = new DataSet();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@User", user);
        cmd.Parameters.AddWithValue("@VechicleClass", Vechicleclass);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        return ds;
    }

    public DataTable Usp_Monthly_Pass_Insert(string tag, string Tollid, string VechileClass, string EffectiveDate, string expirydate, string scheme, string fare, string Maxtrip, string Tripcount)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Monthly_Pass_Insert", con);
        dt = new DataTable();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@TagID", tag);
        cmd.Parameters.AddWithValue("@Toll_id", Tollid);
        cmd.Parameters.AddWithValue("@VechileClass", VechileClass);
        cmd.Parameters.AddWithValue("@EffectiveDate", EffectiveDate);
        cmd.Parameters.AddWithValue("@ExpiryDate", expirydate);
        cmd.Parameters.AddWithValue("@Scheme", scheme);
        cmd.Parameters.AddWithValue("@Fare", fare);
        cmd.Parameters.AddWithValue("@MaxTrip", Maxtrip);
        cmd.Parameters.AddWithValue("@TripCount", Tripcount);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }



    public DataTable Usp_Add_New_Tags(string tag, string Tollid, string from, string To, string Description, string user)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Add_New_Tags", con);
        dt = new DataTable();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@TollId", Tollid);
        cmd.Parameters.AddWithValue("@TagID", tag);
        cmd.Parameters.AddWithValue("@From", from);
        cmd.Parameters.AddWithValue("@To", To);
        cmd.Parameters.AddWithValue("@Description", Description);
        cmd.Parameters.AddWithValue("@User", user);


        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_Get_EChargeSlip(string InVoiceNo, string api_date_time,string tran_type)
    {
        try
        {
            dt = new DataTable();
          
            try
            {
		//MessageBox.Show("InVoiceNo" + InVoiceNo);
		//MessageBox.Show("api_date_time" + api_date_time);
               // System.Collections.Hashtable htMnIndent = new System.Collections.Hashtable();
               // htMnIndent.Add("@InVoiceNo", InVoiceNo);
               // htMnIndent.Add("@api_date_time", api_date_time);
               // dt = objdal.ExecuteProcuderedt("USP_Get_EChargeSlipData ", htMnIndent);
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
                con = new SqlConnection(DAL.Base64Decode(_connectionstring));
                SqlCommand cmd = new SqlCommand("USP_Get_EChargeSlipData", con);

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@InVoiceNo", InVoiceNo);
                cmd.Parameters.AddWithValue("@api_date_time", api_date_time);
		cmd.Parameters.AddWithValue("@tran_type", tran_type);
                cmd.CommandTimeout = 600000;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
		MessageBox.Show("api_date_time" + ex.ToString());
                throw;
            }
        }
        catch (Exception ex)
        {

            throw ex;
        }
        return dt;
    }

    public DataTable Usp_Request_Pay(string id, string tag, string VehRegNo, string TID, string TagStatus, string CCHVechicle, string TripType, string NoOfJou, string PriceTy, string Amount, string bank, string exccode, string issuedate, string comvechicle, string Toll_ID, string fromdate, string todate, string tollname, string Descrip)
    {
        dt = new DataTable();
        try { 
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Request_Pay", con);
     
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@TagID", tag);
        cmd.Parameters.AddWithValue("@vehRegNo", VehRegNo);
        cmd.Parameters.AddWithValue("@TID", TID);
        cmd.Parameters.AddWithValue("@TagStatus", TagStatus);
        cmd.Parameters.AddWithValue("@CCHVechile", CCHVechicle);
        cmd.Parameters.AddWithValue("@TripType", TripType);
        cmd.Parameters.AddWithValue("@NumberofJou", NoOfJou);
        cmd.Parameters.AddWithValue("@PriceTy", PriceTy);
        cmd.Parameters.AddWithValue("@Amount", Amount);
        cmd.Parameters.AddWithValue("@bank", bank);
        cmd.Parameters.AddWithValue("@exccode", exccode);
        cmd.Parameters.AddWithValue("@issuedate", issuedate);
        cmd.Parameters.AddWithValue("@comvechicle", comvechicle);
        cmd.Parameters.AddWithValue("@TollID", Toll_ID);
        cmd.Parameters.AddWithValue("@FromDate", fromdate);
        cmd.Parameters.AddWithValue("@ToDate", todate);
        cmd.Parameters.AddWithValue("@Tollname", tollname);
        cmd.Parameters.AddWithValue("@Descrip", Descrip);
        cmd.CommandTimeout = 600000;

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        }
        catch(Exception ex)
        {
            MessageBox.Show(ex.ToString());
        }
        return dt;

    }

    public DataTable Usp_Request_Pay_Test(string id, string tag, string VehRegNo, string TagStatus, string CCHVechicle, string TripType, string NoOfJou, string PriceTy, string Amount, string bank, string exccode, string issuedate, string comvechicle, string user, string fromdate, string todate, string Descrip)
    {

        //MessageBox.Show("in Procedures");
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Request_Pay_Test", con);
        dt = new DataTable();
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@TagID", tag);
        cmd.Parameters.AddWithValue("@vehRegNo", VehRegNo);
        cmd.Parameters.AddWithValue("@TagStatus", TagStatus);
        cmd.Parameters.AddWithValue("@CCHVechile", CCHVechicle);
        cmd.Parameters.AddWithValue("@TripType", TripType);
        cmd.Parameters.AddWithValue("@NumberofJou", NoOfJou);
        cmd.Parameters.AddWithValue("@PriceTy", PriceTy);
        cmd.Parameters.AddWithValue("@Amount", Amount);
        cmd.Parameters.AddWithValue("@bank", bank);
        cmd.Parameters.AddWithValue("@exccode", exccode);
        cmd.Parameters.AddWithValue("@issuedate", issuedate);
        cmd.Parameters.AddWithValue("@comvechicle", comvechicle);
        cmd.Parameters.AddWithValue("@user", user);
        cmd.Parameters.AddWithValue("@FromDate", fromdate);
        cmd.Parameters.AddWithValue("@ToDate", todate);
        cmd.Parameters.AddWithValue("@Descrip", Descrip);

        //MessageBox.Show("AFTER PARAMS" + user);
        //MessageBox.Show("ID"+id);
        //MessageBox.Show("TAG"+tag);
        //MessageBox.Show("VEH"+VehRegNo);
        //MessageBox.Show("TAGSTA"+TagStatus);
        //MessageBox.Show("CCH"+CCHVechicle);
        //MessageBox.Show("TRIP"+TripType);
        //MessageBox.Show("NOOFJOU"+NoOfJou);
        //MessageBox.Show("PRICE"+PriceTy);
        //MessageBox.Show("AMT"+Amount);
        //MessageBox.Show("BANK"+bank);
        //MessageBox.Show("EXCCODE"+exccode);
        //MessageBox.Show("IISSUEDAT"+issuedate);
        //MessageBox.Show("COMVEH"+comvechicle);
        //MessageBox.Show("USER"+user);
        //MessageBox.Show("FRMDTE"+fromdate);
        //MessageBox.Show("TODATE"+todate);


        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;

        //MessageBox.Show(ex.Message.ToString());//
        //}
    }


    public DataTable Usp_Request_Pay_SBIePay(string tag, string VehRegNo, string MrechantOrderID, string SBIRefrenceNo, string TagStatus, string CCHVechicle, string TripType, string NoOfJou, string PriceTy, string Amount, string PayMode, string fromdate, string todate, string tollname, string Descrip, string bankCode, string BankReferenceNo, string tollid, string SBIStatus, string CIN, string RequestTime, string BankName, string IssueDate, string ExcCode)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        dt = new DataTable();
        try
        {
            con = new SqlConnection(DAL.Base64Decode(_connectionstring));
            SqlCommand cmd = new SqlCommand("Usp_Request_Pay_SBIePay", con);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@TagID", tag);
            cmd.Parameters.AddWithValue("@vehRegNo", VehRegNo);
            cmd.Parameters.AddWithValue("@TagStatus", TagStatus);
            cmd.Parameters.AddWithValue("@CCHVechile", CCHVechicle);
            cmd.Parameters.AddWithValue("@TripType", TripType);
            cmd.Parameters.AddWithValue("@NumberofJou", NoOfJou);
            cmd.Parameters.AddWithValue("@PriceTy", PriceTy);
            cmd.Parameters.AddWithValue("@Amount", Amount);
            cmd.Parameters.AddWithValue("@MerchantOrderId", MrechantOrderID);
            cmd.Parameters.AddWithValue("@SBIRefrenceNo", SBIRefrenceNo);
            cmd.Parameters.AddWithValue("@PayMode", PayMode);
            cmd.Parameters.AddWithValue("@FromDate", fromdate);
            cmd.Parameters.AddWithValue("@ToDate", todate);
            cmd.Parameters.AddWithValue("@Tollname", tollname);
            cmd.Parameters.AddWithValue("@Descrip", Descrip);
            cmd.Parameters.AddWithValue("@bankCode", bankCode);
            cmd.Parameters.AddWithValue("@bankReferenceNo", BankReferenceNo);
            cmd.Parameters.AddWithValue("@CIN", CIN);
            cmd.Parameters.AddWithValue("@RequestTime", RequestTime);
            cmd.Parameters.AddWithValue("@toll_id", tollid);
            cmd.Parameters.AddWithValue("@SBIStatus", SBIStatus);
            cmd.Parameters.AddWithValue("@BankName", BankName);
            cmd.Parameters.AddWithValue("@IssueDate", IssueDate);
            cmd.Parameters.AddWithValue("@ExcCode", ExcCode);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message.ToString());
        }
        return dt;
    }

    public DataTable Usp_Monthly_Pass_IssuenceSearch(string Tagid, string VehRegNo)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Monthly_Pass_IssuenceSearch", con);
        cmd.Parameters.AddWithValue("@TagID", Tagid);
        cmd.Parameters.AddWithValue("@VehNo", VehRegNo);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }




    public DataTable Usp_Monthly_Pass(string Tagid, string Iuser)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        con.Open();
        SqlCommand cmd = new SqlCommand("Usp_Monthly_Pass", con);
        cmd.Parameters.AddWithValue("@TagID", Tagid);
        cmd.CommandTimeout = 600000;
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        con.Close();
        con.Dispose();
        return dt;
    }

    public DataTable Usp_Monthly_Pass(string Tagid,string VehNo, string Iuser)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        con.Open();
        SqlCommand cmd = new SqlCommand("Usp_Monthly_Pass", con);
        cmd.Parameters.AddWithValue("@TagID", Tagid);
        cmd.Parameters.AddWithValue("@VehNo", VehNo);
        cmd.Parameters.AddWithValue("@iUser", Iuser);
        cmd.CommandTimeout = 600000;
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        con.Close();
        con.Dispose();
        return dt;
    }


    public DataTable SaveRRN(string RRN, int iuser)
    {
        try
        {
            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            con = new SqlConnection(DAL.Base64Decode(_connectionstring));
            SqlCommand cmd = new SqlCommand("Usp_Process_RRN", con);
            cmd.Parameters.AddWithValue("@Iuser", iuser);
            cmd.Parameters.AddWithValue("@RRN", RRN);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            //    executeNonQuery();
            da.Fill(dt);

        }
        catch
        {

        }
        return dt;

    }

    public DataTable Usp_GET_Password(string id)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_GET_Password", con);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable getLogs(int iUser)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Generate_Files_BULK_Web", con);
        cmd.Parameters.AddWithValue("@iUser", iUser);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }


    public DataTable Usp_Update_Users(string iUser, string Active, string pass)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Update_Users", con);
        cmd.Parameters.AddWithValue("@iUser", iUser);
        cmd.Parameters.AddWithValue("@isActive", Active);
        cmd.Parameters.AddWithValue("@Password", pass);

        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_upload_EGCS_File(object[] values)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

        DataTable dt = new DataTable();
        string spname = "Usp_upload_EGCS_File";
        string[] parameters = new string[]
            {
                "@TableName",
                "@TransactionSequenceNumber",
                "@TagID",
                "@FunctionCode",
                "@TransactionDateandtime",
                "@RRN",
                "@IssuerID",
                "@AcquirerID",
                "@TransactionAmount",
                "@SettlementAmount",
                "@SettlementindicatorDr_Cr",
                "@SettlementCurrency",
                "@Financial_Non_FinancialIndicator",
                "@SettlementDate",
                "@FeeTypeCode1",
                "@InterchangeCategory1",
                "@Feeamount1",
                "@FeeDR_CRIndicator1",
                "@FeeCurrency1",
                "@FeeTypeCode2",
                "@InterchangeCategory2",
                "@Feeamount2",
                "@FeeDR_CRIndicator2",
                "@FeeCurrency2",
                "@FeeTypeCode3",
                "@InterchangeCategory3",
                "@Feeamount3",
                "@FeeDR_CRIndicator3",
                "@FeeCurrency3",
                "@TransactionType",
                "@MerchantID",
                "@TID",
                "@TransactionStatus"
            };
        dt = setDefaults(spname, parameters, values);
        return dt;
    }

    public DataTable Usp_upload_ChargeBack_File(object[] values)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

        DataTable dt = new DataTable();
        string spname = "Usp_upload_ChargeBack_File";
        string[] parameters = new string[]
            {
                "@TableName",
                "@ReportDate",
                "@ChargebackRaiseDate",
                "@ChargebackRaisedSettlementDate",
                "@CaseNumber",
                "@FunctionCodeandDescription",
                "@TransactionSequenceNumber",
                "@TagID",
                "@TransactionDateandTime",
                "@TransactionSettlementDate",
                "@RRN",
                "@TransactionType",
                "@MerchantID",
                "@TID",
                "@TransactionStatus",
                "@TAGStatus",
                "@AVC",
                "@TransactionCurrencyCode",
                "@SettlementAmount",
                "@CreditAdjustmentAmount",
                "@DebitAdjustmentAmount",
                "@OriginatorPoint",
                "@AcquirerID",
                "@TransactionOriginatorInstitutionPID",
                "@AcquirerNameandCountry",
                "@IIN",
                "@TransactionDestinationInstitutionPID",
                "@IssuerNameandCountry",
                "@VehicleRegistrationNumber",
                "@VehicleClass",
                "@VehicleType",
                "@Merchanttype",
                "@SubMerchantType",
                "@FinancialandNonFinancialIndicator",
                "@ChargebackReasoncode",
                "@ChargebackReasoncodedescription",
                "@ChargebackAmount",
                "@ChargebackFullandPartialIndicator",
                "@ChargebackDeadlinedate",
                "@ChargebackMemberMessagetext",
                "@ChargebackDocumentIndicator",
                "@ChargebackDocumentAttachedDate",
                "@DaysAged",
                "@Daystoact"
                };
        dt = setDefaults(spname, parameters, values);
        return dt;
    }


    public DataTable Usp_upload_ChargeBack_Accept_File(object[] values)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

        DataTable dt = new DataTable();
        string spname = "Usp_upload_ChargeBack_Accept_File";
        string[] parameters = new string[]
            {
                "@TableName",
                "@ReportDate",
                "@ChargebackRaiseDate",
                "@ChargebackRaisedSettlementDate",
                "@CaseNumber",
                "@FunctionCodeandDescription",
                "@TransactionSequenceNumber",
                "@TagID",
                "@TransactionDateandTime",
                "@TransactionSettlementDate",
                "@RRN",
                "@TransactionType",
                "@MerchantID",
                "@TID",
                "@TransactionStatus",
                "@TAGStatus",
                "@AVC",
                "@TransactionCurrencyCode",
                "@SettlementAmount",
                "@CreditAdjustmentAmount",
                "@DebitAdjustmentAmount",
                "@OriginatorPoint",
                "@AcquirerID",
                "@TransactionOriginatorInstitutionPID",
                "@AcquirerNameandCountry",
                "@IIN",
                "@TransactionDestinationInstitutionPID",
                "@IssuerNameandCountry",
                "@VehicleRegistrationNumber",
                "@VehicleClass",
                "@VehicleType",
                "@Merchanttype",
                "@SubMerchantType",
                "@FinancialandNonFinancialIndicator",
                "@ChargebackReasoncode",
                "@ChargebackReasoncodedescription",
                "@ChargebackAmount",
                "@ChargebackFullandPartialIndicator",
                "@ChargebackDeadlinedate",
                "@ChargebackMemberMessagetext",
                "@ChargebackDocumentIndicator",
                "@DaysAged",
                "@Daystoact",
                "@ChargebackAcceptanceRaiseDate",
                "@ChargebackAcceptanceSettlementDate",
                "@ChargebackAcceptanceAmount"
                };
        dt = setDefaults(spname, parameters, values);
        return dt;
    }


    public DataTable Usp_upload_ChargeBack_Represent_File(object[] values)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

        DataTable dt = new DataTable();
        string spname = "Usp_upload_ChargeBack_Represent_File";
        string[] parameters = new string[]
            {
                "@TableName",
                "@ReportDate",
                "@RepresentmentRaiseDate",
                "@RepresentmentRaisedSettlementDate",
                "@CaseNumber",
                "@FunctionCodeandDescription",
                "@TransactionSequenceNumber",
                "@TagID",
                "@TransactionDateandTime",
                "@TransactionSettlementDate",
                "@RRN",
                "@TransactionType",
                "@MerchantID",
                "@TID",
                "@TransactionStatus",
                "@TAGStatus",
                "@AVC",
                "@TransactionCurrencyCode",
                "@SettlementAmount",
                "@CreditAdjustmentAmount",
                "@DebitAdjustmentAmount",
                "@OriginatorPoint",
                "@AcquirerID",
                "@TransactionOriginatorInstitutionPID",
                "@AcquirerNameandCountry",
                "@IIN",
                "@TransactionDestinationInstitutionPID",
                "@IssuerNameandCountry",
                "@VehicleRegistrationNumber",
                "@VehicleClass",
                "@VehicleType",
                "@Merchanttype",
                "@SubMerchantType",
                "@FinancialandNonFinancialIndicator",
                "@ChargebackReasoncode",
                "@ChargebackReasoncodedescription",
                "@ChargebackAmount",
                "@ChargebackFullandPartialIndicator",
                "@ChargebackRaiseDate",
                "@ChargebackRaisedSettlementDate",
                "@ChargebackMemberMessagetext",
                "@ChargebackDocumentIndicator",
                "@ChargebackDocumentAttachedDate",
                "@RepresentmentReasoncode",
                "@RepresentmentReasoncodedescription",
                "@RepresentmentAmount",
                "@RepresentmentFullorPartialIndicator",
                "@RepresentmentDeadlinedate",
                "@RepresentmentMemberMessagetext",
                "@RepresentmentDocumentIndicator",
                "@RepresentmentDocumentAttachedDate",
                "@DaysAged",
                "@Daystoact"
                };
        dt = setDefaults(spname, parameters, values);
        return dt;
    }


    public DataTable Usp_upload_ChargeBack_Recovery_File(object[] values)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

        DataTable dt = new DataTable();
        string spname = "Usp_upload_ChargeBack_Recovery_File";
        string[] parameters = new string[]
            {
                "@TableName",
                "@ChargebackRecoveryDate",
                "@TagID",
                "@RRN",
                "@MerchantID",
                "@ChargebackAmount",
                "@ChargebackAcceptanceAmount",
                "@SettlementAmount"
            };
        dt = setDefaults(spname, parameters, values);
        return dt;
    }

    public DataTable Usp_Get_TagID_for_VehicleRegNo(object[] values)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        //string decode = DAL.Base64Decode(_connectionstring);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));

        DataTable dt = new DataTable();
        string spname = "Usp_Get_TagID_for_VehicleRegNo";
        string[] parameters = new string[]
            {
                "@VehicleRegNo",
                "@TagId"
            };
        dt = setDefaults(spname, parameters, values);
        return dt;
    }

    public DataTable ReadTest(string filename, string extension)
    {
        dt = new DataTable();
        int colcount = 0;
        int rowcount = 0;
        int iIndex = 0;

        // Read sample data from CSV file
        using (CsvFileReader reader = new CsvFileReader(filename))
        {
            CsvRow row = new CsvRow();

            while (reader.ReadRow(row))
            {
                DataRow dr = dt.NewRow();
                colcount = 0;
                foreach (string s in row)
                {
                    iIndex = 0;
                    Console.Write(s);
                    if (rowcount == 0)
                    {
                        dt.Columns.Add(s);
                    }
                    else
                    {
                        if (iIndex == 0)
                        {
                            //dr= dt.NewRow();

                        }
                        dr[colcount] = s;
                        //dt.Rows[rowcount][colcount] = s;
                        colcount = colcount + 1;
                    }
                    iIndex = iIndex + 1;

                    //Console.Write(" ");
                    //dt.Rows.Add(s);
                }
                if (rowcount > 0)
                    dt.Rows.Add(dr);
                rowcount = rowcount + 1;

                //Console.WriteLine();
            }
        }
        return dt;
    }

    /// <summary>
    /// Class to store one CSV row
    /// </summary>
    public class CsvRow : List<string>
    {
        public string LineText { get; set; }
    }

    /// <summary>
    /// Class to write data to a CSV file
    /// </summary>
    public class CsvFileWriter : StreamWriter
    {
        public CsvFileWriter(Stream stream)
            : base(stream)
        {
        }

        public CsvFileWriter(string filename)
            : base(filename)
        {
        }

        /// <summary>
        /// Writes a single row to a CSV file.
        /// </summary>
        /// <param name="row">The row to be written</param>
        public void WriteRow(CsvRow row)
        {
            StringBuilder builder = new StringBuilder();
            bool firstColumn = true;
            foreach (string value in row)
            {
                // Add separator if this isn't the first value
                if (!firstColumn)
                    builder.Append(',');
                // Implement special handling for values that contain comma or quote
                // Enclose in quotes and double up any double quotes
                if (value.IndexOfAny(new char[] { '"', ',' }) != -1)
                    builder.AppendFormat("\"{0}\"", value.Replace("\"", "\"\""));
                else
                    builder.Append(value);
                firstColumn = false;
            }
            row.LineText = builder.ToString();
            WriteLine(row.LineText);
        }
    }

    /// <summary>
    /// Class to read data from a CSV file
    /// </summary>
    public class CsvFileReader : StreamReader
    {
        public CsvFileReader(Stream stream)
            : base(stream)
        {
        }

        public CsvFileReader(string filename)
            : base(filename)
        {
        }

        /// <summary>
        /// Reads a row of data from a CSV file
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public bool ReadRow(CsvRow row)
        {
            row.LineText = ReadLine();
            if (String.IsNullOrEmpty(row.LineText))
                return false;

            int pos = 0;
            int rows = 0;

            while (pos < row.LineText.Length)
            {
                string value;

                // Special handling for quoted field
                if (row.LineText[pos] == '"')
                {
                    // Skip initial quote
                    pos++;

                    // Parse quoted value
                    int start = pos;
                    while (pos < row.LineText.Length)
                    {
                        // Test for quote character
                        if (row.LineText[pos] == '"')
                        {
                            // Found one
                            pos++;

                            // If two quotes together, keep one
                            // Otherwise, indicates end of value
                            if (pos >= row.LineText.Length || row.LineText[pos] != '"')
                            {
                                pos--;
                                break;
                            }
                        }
                        pos++;
                    }
                    value = row.LineText.Substring(start, pos - start);
                    value = value.Replace("\"\"", "\"");
                }
                else
                {
                    // Parse unquoted value
                    int start = pos;
                    while (pos < row.LineText.Length && row.LineText[pos] != ',')
                        pos++;
                    value = row.LineText.Substring(start, pos - start);
                }

                // Add field to list
                if (rows < row.Count)
                    row[rows] = value;
                else
                    row.Add(value);
                rows++;

                // Eat up to and including next comma
                while (pos < row.LineText.Length && row.LineText[pos] != ',')
                    pos++;
                if (pos < row.LineText.Length)
                    pos++;
            }
            // Delete any unused items
            while (row.Count > rows)
                row.RemoveAt(rows);

            // Return true if any columns read
            return (row.Count > 0);
        }
    }

    public DataTable USP_Insert_Tariff_Details(string plaza, string Jaurney_Type, string is_Monthly, string Trip_Count, string Trip_Type, string start_date, string End_Date, string user, string Class1Amt, string Class2Amt,string Class3Amt,string Class4Amt,string Class5Amt,string Class6Amt,string Class7Amt,string Class8Amt,string Class9Amt)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("USP_Insert_Tariff_Details", con);
        cmd.Parameters.AddWithValue("@Toll", plaza);
        cmd.Parameters.AddWithValue("@Jaurney_Type", Jaurney_Type);
        cmd.Parameters.AddWithValue("@Is_Monthly", is_Monthly);
        cmd.Parameters.AddWithValue("@Trip_Count", Trip_Count);
        cmd.Parameters.AddWithValue("@Trip_Type", Trip_Type);
        cmd.Parameters.AddWithValue("@Start_Date", start_date);
        cmd.Parameters.AddWithValue("@End_Date", End_Date);
        cmd.Parameters.AddWithValue("@inserted_by", user);
        cmd.Parameters.AddWithValue("@Class1Amt", Class1Amt);
        cmd.Parameters.AddWithValue("@Class2Amt", Class2Amt);
        cmd.Parameters.AddWithValue("@Class3Amt", Class3Amt);
        cmd.Parameters.AddWithValue("@Class4Amt", Class4Amt);
        cmd.Parameters.AddWithValue("@Class5Amt", Class5Amt);
        cmd.Parameters.AddWithValue("@Class6Amt", Class6Amt);
        cmd.Parameters.AddWithValue("@Class7Amt", Class7Amt);
        cmd.Parameters.AddWithValue("@Class8Amt", Class8Amt);
        cmd.Parameters.AddWithValue("@Class9Amt", Class9Amt);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable USP_Update_Tariff_Details(string tariff_id,string plaza, string Jaurney_Type, string is_Monthly, string Trip_Count, string Trip_Type, string start_date, string End_Date, string user, string Class1Amt, string Class2Amt, string Class3Amt, string Class4Amt, string Class5Amt, string Class6Amt, string Class7Amt, string Class8Amt, string Class9Amt)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("USP_Update_Tariff_Details", con);
        cmd.Parameters.AddWithValue("@Tariff_id", tariff_id);
        cmd.Parameters.AddWithValue("@Toll", plaza);
        cmd.Parameters.AddWithValue("@Jaurney_Type", Jaurney_Type);
        cmd.Parameters.AddWithValue("@Is_Monthly", is_Monthly);
        cmd.Parameters.AddWithValue("@Trip_Count", Trip_Count);
        cmd.Parameters.AddWithValue("@Trip_Type", Trip_Type);
        cmd.Parameters.AddWithValue("@Start_Date", start_date);
        cmd.Parameters.AddWithValue("@End_Date", End_Date);
        cmd.Parameters.AddWithValue("@inserted_by", user);
        cmd.Parameters.AddWithValue("@Class1Amt", Class1Amt);
        cmd.Parameters.AddWithValue("@Class2Amt", Class2Amt);
        cmd.Parameters.AddWithValue("@Class3Amt", Class3Amt);
        cmd.Parameters.AddWithValue("@Class4Amt", Class4Amt);
        cmd.Parameters.AddWithValue("@Class5Amt", Class5Amt);
        cmd.Parameters.AddWithValue("@Class6Amt", Class6Amt);
        cmd.Parameters.AddWithValue("@Class7Amt", Class7Amt);
        cmd.Parameters.AddWithValue("@Class8Amt", Class8Amt);
        cmd.Parameters.AddWithValue("@Class9Amt", Class9Amt);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable USP_Delete_TariffDetails(string tariff_id,string iUser)
    {
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("USP_Delete_TariffDetails", con);
        cmd.Parameters.AddWithValue("@Tariff_id", tariff_id);
        cmd.Parameters.AddWithValue("@iUser", iUser);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataSet USP_Get_TariffDetailsBy_ID(string tariff_id, string iUser)
    {
        DataSet dt = new DataSet();
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("USP_Get_Tariff_DetailsBY_ID", con);
        cmd.Parameters.AddWithValue("@Tariff_id", tariff_id);
        cmd.Parameters.AddWithValue("@iUser", iUser);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }
    public DataSet USP_Get_Tariff_Details(string User)
    {
        DataSet dt = new DataSet();
        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("USP_Get_Tariff_Details", con);
        cmd.Parameters.AddWithValue("@iUser", User);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public DataTable Usp_local_Com_Regis(string iuser, string Tag_ID, string Vehical_No, string TID, string Vehical_Class, string Valid_from, string Pass_Type, string amount)
    {

        string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

        con = new SqlConnection(DAL.Base64Decode(_connectionstring));
        SqlCommand cmd = new SqlCommand("Usp_Insert_LocalCommercial_Registraion", con);
        dt = new DataTable();
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@iuser", iuser);
        cmd.Parameters.AddWithValue("@Tag_ID", Tag_ID);
        cmd.Parameters.AddWithValue("@Vehical_No", Vehical_No);
        cmd.Parameters.AddWithValue("@TID", TID);
        cmd.Parameters.AddWithValue("@Vehical_Class", Vehical_Class);
        cmd.Parameters.AddWithValue("@Valid_From", Valid_from);
        cmd.Parameters.AddWithValue("@Pass_type", Pass_Type);
        cmd.Parameters.AddWithValue("@amount", amount);
        cmd.Parameters.AddWithValue("@isActive", true);




        SqlDataAdapter da = new SqlDataAdapter(cmd);
        con.Open();
        //cmd.ExecuteNonQuery();
        //MessageBox.Show("Data Inserted Successfully");
        con.Close();




        da.Fill(dt);
        return dt;

    }


}