﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.IO;
using System.Data.OleDb;
/// <summary>
/// Summary description for BAL
/// </summary>
public class BLL
{
    SqlHelper _helper = new SqlHelper();
    DataTable dt = new DataTable();
    public string UserName { get; set; }
    public string password { get; set; }
    public string rrn_data { get; set; }
    //public string rrn_data2 { get; set; }
    public string tag_data { get; set; }
    public string Toll_Id { get; set; }
    public string startDate { get; set; }
    public string endDate { get; set; }
    public string  User { get; set; }

    Hashtable hashparams = new Hashtable();
    public BLL()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public void GetDataTable(string strQuery, Hashtable hashparams, CommandType cmndtype,out DataTable dt)
    {
        dt=_helper.ExecuteProcuderedt(strQuery, hashparams); 
    }

    public void GetDataTable(string strQuery, CommandType cmndtype, out DataTable dt)
    {
        dt = _helper.ExecuteProcuderedt(strQuery);
    }
    public void GetDataset(string strQuery, Hashtable hashparams, CommandType cmndtype)
    {
       _helper.ExecuteProcudereds(strQuery, hashparams);
    }
    public void GetDataset(string strQuery, Hashtable hashparams, CommandType cmndtype, out DataSet ds)
    {
        ds = _helper.ExecuteProcudereds(strQuery, hashparams);
    }
   
    public string GetCommaSeparatedString(string Filepath, string path)
    {
        string extension = Path.GetExtension(Filepath);
        string data = "";
        string data1 = "";
        if (extension == ".txt")
        {
             //rrn_data = System.IO.File.ReadAllText(Filepath);
             string[] columns = null;
             var lines = File.ReadAllLines(Filepath);

             // assuming the first row contains the columns information
             ////if (lines.Count() > 0)
             ////{
             ////    columns = lines[0].Split(new char[] { ',' });

             ////    foreach (var column in columns)
             ////        dt.Columns.Add(column);
             ////}

             ////// reading rest of the data
             ////for (int i = 1; i < lines.Count(); i++)
             ////{
             ////    DataRow dr = dt.NewRow();
             ////    string[] values = lines[i].Split(new char[] { ',' });

             ////    for (int j = 0; j < values.Count() && j < columns.Count(); j++)
             ////        dr[j] = values[j];

             ////    dt.Rows.Add(dr);
             ////}
             foreach (string line in lines)
             {
                 if (!string.IsNullOrEmpty(data))
                 {
                    data = data + "," + line;
                 }
                 else
                 {
                    data = data + line;
                 }

             }
           
           
        }
        else if (extension == ".csv")
        {
            // Connection String to Excel Workbook

            //string excelConnectionString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + Filepath + "';Extended Properties='Excel 8.0;HDR=YES'", path);

            //OleDbConnection connection = new OleDbConnection();
            //connection.ConnectionString = excelConnectionString;
            //OleDbCommand command = new OleDbCommand("select * from [Sheet1$]", connection);
            //OleDbDataAdapter da = new OleDbDataAdapter(command);
            //connection.Open();

            // dt = new DataTable();
            //  da.Fill(dt);
            DAL db = new DAL();
            FileInfo fi = new FileInfo(Filepath);
            string ext = fi.Extension;
            dt = new DataTable();
            dt = db.ReadTest(Filepath, ext);

            foreach (DataRow dr in dt.Rows)
            {
                if (!string.IsNullOrEmpty(data))
                {
                    data = data + "," + dr[0].ToString();                 
                }
                else
                {
                    data = data + dr[0].ToString();                 
                }

            }

        }
        return data;
  
    }

    public string GetCommaSeparatedString2(string Filepath, string path)
    {
        string extension = Path.GetExtension(Filepath);
        string data = "";
        if (extension == ".txt")
        {           
            string[] columns = null;
            var lines = File.ReadAllLines(Filepath);
            foreach (string line in lines)
            {
                if (!string.IsNullOrEmpty(data))
                {
                    data = data + "," + line;
                }
                else
                {
                    data = data + line;
                }

            }
        }
        else if (extension == ".csv")
        {       
            DAL db = new DAL();
            FileInfo fi = new FileInfo(Filepath);
            string ext = fi.Extension;
            dt = new DataTable();
            dt = db.ReadTest(Filepath, ext);

            foreach (DataRow dr in dt.Rows)
            {
                if (!string.IsNullOrEmpty(data))
                {
                    data = data + "," + dr[0].ToString() + "-" + dr[1].ToString();               
                }
                else
                {
                    data = data + dr[0].ToString() + "-" + dr[1].ToString();           
                }

            }

        }
        return data;

    }

}