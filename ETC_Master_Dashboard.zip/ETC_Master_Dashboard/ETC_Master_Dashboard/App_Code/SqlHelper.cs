﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.IO; 


public interface ConnectObjects : IDisposable
{
    DataTable ExecuteProcuderedt(string procName, Hashtable parms);
    DataSet ExecuteProcudereds(string procName, Hashtable parms);
    int ExecuteQuery(string procName, Hashtable parms);
    int ExecuteQuerywithOutputparams(SqlCommand cmd);
    string ExecuteScalarqureyWithParamertes(string procName, Hashtable parms);
    int ExecuteQueryWithOutParam(string procName, Hashtable parms);

}

public class SqlHelper : ConnectObjects
{
    // Flag: Has Dispose already been called? 
    bool disposed = false;
    string status;
    int sts;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    DataSet ds;

    // Public implementation of Dispose pattern callable by consumers. 
    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    // Protected implementation of Dispose pattern. 
    protected virtual void Dispose(bool disposing)
    {
        if (disposed)
            return;

        if (disposing)
        {
            // Free any other managed objects here. 
            //
        }

        // Free any unmanaged objects here. 
        //
        disposed = true;
    }

    string ConnectionString = string.Empty;
    static SqlConnection con;

    public SqlHelper()
    {
        ConnectionString = ConfigurationManager.ConnectionStrings["conString"].ConnectionString;  //conn for live testing & change db in config file to TEST
        con = new SqlConnection(DAL.Base64Decode(ConnectionString));

       

    }

    public void SetConnection()
    {
        if (ConnectionString == string.Empty)
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["SwitchCon"].ConnectionString;
        }
        con = new SqlConnection(DAL.Base64Decode(ConnectionString));
    }
     
    public DataTable ExecuteProcuderedt(string procName, Hashtable parms)
    {

        setDefaults(procName);
        if (parms.Count > 0)
        {
            foreach (DictionaryEntry de in parms)
            {
                cmd.Parameters.AddWithValue(de.Key.ToString(), de.Value);
		cmd.CommandTimeout=300;
            }
        }

        fillDT();
        return dt;
    }

    public DataTable ExecuteProcuderedt(string procName)
    {
        setDefaults(procName);
	//cmd.CommandTimeout=300;
        fillDT();
        return dt;
    }

    public string ExecuteScalarqureyWithParamertes(string procName, Hashtable parms)
    {
        status = "";
        setDefaults(procName);
        if (parms.Count > 0)
        {
            foreach (DictionaryEntry de in parms)
            {
                cmd.Parameters.AddWithValue(de.Key.ToString(), de.Value);
		cmd.CommandTimeout=300;
            }
        }
        status = ExcuteSclar();
        return status;
    }

    public DataSet ExecuteProcudereds(string procName, Hashtable parms)
    {
        setDefaults(procName);
        if (parms.Count > 0)
        {
            foreach (DictionaryEntry de in parms)
            {
                cmd.Parameters.AddWithValue(de.Key.ToString(), de.Value);
            }
        }
        fillDS();
        return ds;
    }

    public int ExecuteQuery(string procName, Hashtable parms)
    {
        sts = 0;
        setDefaults(procName);
        if (parms.Count > 0)
        {
            foreach (DictionaryEntry de in parms)
            {
                cmd.Parameters.AddWithValue(de.Key.ToString(), de.Value);
            }
        }
        sts = executeNonQuery();
        return sts;
    }

    public int ExecuteQuerywithOutputparams(SqlCommand cmd)
    {
        if (con == null)
        {
            SetConnection();
        }
        cmd.Connection = con;
        if (con.State == ConnectionState.Closed)
            con.Open();
        int result = cmd.ExecuteNonQuery();
        return result;
    }

    public int ExecuteQueryWithOutParam(string procName, Hashtable parms)
    {
        sts = 0;

        SqlParameter sqlparam = new SqlParameter();
        setDefaults(procName);
        if (parms.Count > 0)
        {
            foreach (DictionaryEntry de in parms)
            {
                if (de.Key.ToString().Contains("_out"))
                {
                    sqlparam = new SqlParameter(de.Key.ToString(), de.Value);
                    sqlparam.DbType = DbType.Int32;
                    sqlparam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(sqlparam);
                }
                else
                {
                    cmd.Parameters.AddWithValue(de.Key.ToString(), de.Value);
                }
            }
        }
        sts = executeNonQuery();
        return sts;

    }

    #region Reusable


    void setDefaults(string spname)
    {
        string str = "Server=172.16.15.36;Database=ETCData;User Id=appadmin;Password=@pp@dm!n;Connection Timeout=1000";
        DAL.Base64Encode(str);
        con = new SqlConnection(DAL.Base64Decode(ConnectionString));
        cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = spname;
        cmd.Connection = con;
        // conOpen();
        cmd.CommandTimeout = 1000;
    }

    void conOpen()
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
    }

    void conClose()
    {
        if (con.State == ConnectionState.Open)
            con.Close();
    }

    int executeNonQuery()
    {
        sts = 0;
        conOpen();
        sts = cmd.ExecuteNonQuery();
        conClose();
        return sts;
    }

    string ExcuteSclar()
    {
        status = "";
        conOpen();
        status = Convert.ToString(cmd.ExecuteScalar());
        conClose();
        return status;
    }

    void fillDT()
    {
        dt = new DataTable();
        da = new SqlDataAdapter(cmd);
        da.Fill(dt);
    }

    void fillDS()
    {
        ds = new DataSet();
        da = new SqlDataAdapter(cmd);
        da.Fill(ds);
    }

    #endregion
}