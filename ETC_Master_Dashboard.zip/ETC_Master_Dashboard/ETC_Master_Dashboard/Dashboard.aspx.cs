﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Dashboard : System.Web.UI.Page
{
    DataTable dt = new DataTable();
    //BLL _bll = new BLL();
    Hashtable hashparams = new Hashtable();
    protected void Page_Load(object sender, EventArgs e)
    {
        //Response.Cache.SetNoStore();
        //Response.Cache.SetCacheability(HttpCacheability.NoCache);

        //string ASPSession = null;
        //string BASPSession = null;
        //if (System.Web.HttpContext.Current.Session["ASPSession"] != null)
        //{
        //    ASPSession = Session["ASPSession"].ToString();
        //}
        //if (Request.Cookies["ASP.NET_SessionId"] != null)
        //{
        //    BASPSession = Request.Cookies["ASP.NET_SessionId"].Value;
        //}
        //if (BASPSession == ASPSession)
        //{
        //    string SessionAuth = null;
        //    if (System.Web.HttpContext.Current.Session["AuthToken"] != null)
        //    {
        //        SessionAuth = Session["AuthToken"].ToString();
        //    }
        //    string auth = null;
        //    if (Request.Cookies["MPor_AuthToken"] != null)
        //    {
        //        auth = Request.Cookies["MPor_AuthToken"].Value;
        //    }
        //    if (SessionAuth == auth)
        //    {
        //        if (Session["DisplayName"] != null)
        //        {
                    if (!IsPostBack)
                    {
                        LinkDashBoard_Click();
        // LinkDashBoardTollFieTable();
        GetChartData();
        DataTable dt = new DataTable();
        dt.Columns.Add("id", typeof(int));
        dt.Columns.Add("totalTime", typeof(DateTime));
        dt.Columns.Add("totalcnt", typeof(int));
        dt.Columns.Add("success_cnt", typeof(int));
        dt.Columns.Add("decline_cnt", typeof(int));
        dt.Rows.Add(1, "04:50:00", 250, 20, 3);
        dt.Rows.Add(3, "05:00:00", 150, 10, 1);
        dt.Rows.Add(6, "05:10:00", 450, 7, 5);
        }

    //}
    //            else
    //            {
    //                Response.Redirect("LogInNewPage.aspx");
    //            }
    //        }
    //        else
    //        {
    //            Response.Redirect("LogInNewPage.aspx");
    //        }
    //    }
    //    else
    //    {
    //        Response.Redirect("LogInNewPage.aspx");
    //    }

    }
    public string GetChartDataForCBKRaised()
    {
        try
        {
            object TotalTransCount;
            object TotalSuccessCount;
            object TotalDeclinedCount;
            object TotalTxnCount;
            
            DataTable dtParent = new DataTable();
            dtParent.Columns.Add("id", typeof(int));
            dtParent.Columns.Add("Toll_id", typeof(string));
            dtParent.Columns.Add("Overalltotal_cnt", typeof(int));
            dtParent.Columns.Add("success_cnt", typeof(int));
            dtParent.Columns.Add("decline_cnt", typeof(int));
            dtParent.Columns.Add("Count_txn", typeof(int));

            dtParent.Rows.Add(1, "Bagepalli", 3540, 3432, 18, 300);
            dtParent.Rows.Add(2, "Ghaggar", 2000, 4512, 45, 123);

            DataSet ds = new DataSet();
            ds.Tables.Add(dtParent);
            
            TotalTransCount = ds.Tables[0].Compute("Sum(Overalltotal_cnt)", string.Empty);
            TotalSuccessCount = ds.Tables[0].Compute("Sum(success_cnt)", string.Empty);
            TotalDeclinedCount = ds.Tables[0].Compute("Sum(decline_cnt)", string.Empty);
            TotalTxnCount = ds.Tables[0].Compute("Sum(Count_txn)", string.Empty);
            
            List<CBKRaisedSummary> dataList = new List<CBKRaisedSummary>();
            DataTable RaisedSummary = new DataTable();
            RaisedSummary = ds.Tables[0];
            foreach (DataRow drow in RaisedSummary.Rows)
            {
                CBKRaisedSummary details = new CBKRaisedSummary();
                details.Toll_id = drow[1].ToString();
                details.Trans_Count = Convert.ToInt32(drow[2]);
                details.Succcess_Count = Convert.ToInt32(drow[3]);
                dataList.Add(details);
            }

            string JSONString = string.Empty;
            JSONString = JsonConvert.SerializeObject(RaisedSummary);
            return JSONString;

        }
        catch (Exception ex)
        {
            throw ex;
        }

    }


    private void GetChartData()
    {
        try
        {
            object TotalTransCount;
            object TotalSuccessCount;
            object TotalDeclinedCount;
            object TotalTxnCount;
            string role = Convert.ToString(Session["UserRole"]);

            
            DataTable dtParent = new DataTable();
            dtParent.Columns.Add("id", typeof(int));
            dtParent.Columns.Add("Toll_id", typeof(string));
            dtParent.Columns.Add("Overalltotal_cnt", typeof(int));
            dtParent.Columns.Add("success_cnt", typeof(int));
            dtParent.Columns.Add("decline_cnt", typeof(int));
            dtParent.Columns.Add("Count_txn", typeof(int));

            dtParent.Rows.Add(1, "Bagepalli", 3540, 3432, 18, 123);
            dtParent.Rows.Add(2, "Ghaggar", 10, 3432, 18, 123);

            DataSet ds = new DataSet();
            ds.Tables.Add(dtParent);
            
            TotalTransCount = ds.Tables[0].Compute("Sum(Overalltotal_cnt)", string.Empty);
            TotalSuccessCount = ds.Tables[0].Compute("Sum(success_cnt)", string.Empty);
            TotalDeclinedCount = ds.Tables[0].Compute("Sum(decline_cnt)", string.Empty);
            TotalTxnCount = ds.Tables[0].Compute("Sum(Count_txn)", string.Empty);
            lblTotalTransCount.InnerText = TotalTransCount.ToString();
            lblTotalSuccessCount.InnerText = TotalSuccessCount.ToString();
            lblTotalDeclinedCount.InnerText = TotalDeclinedCount.ToString();
            lblTotalTxnCount.InnerText = TotalTxnCount.ToString();
            
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }


    public class AcceptedSummary
    {
        public string Duplicate_transaction_done_at_Toll_Plaza { get; set; }
        public int Vehicle_was_in_black_list { get; set; }
        public string Vehicle_was_in_low_balance_list { get; set; }
        public int Paid_by_other_means { get; set; }
        public string Toll_fare_calculation_error { get; set; }
        public string Wrong_Debit_Adjustment_raised { get; set; }
        public string Other_Specify { get; set; }
        public string NETC_Toll_services_not_availed_Tag_holder_does_not_recognise_the_transaction { get; set; }
        public string Fraudulent_multiple_transaction { get; set; }
        public string Signature_not_validated { get; set; }
        public string Total { get; set; }
    }
    public class CBKRaisedSummary
    {
        public string Toll_id { get; set; }
        public int Trans_Count { get; set; }
        public int Succcess_Count { get; set; }
        //public string Vehicle_was_in_low_balance_list { get; set; }
        //public int Paid_by_other_means { get; set; }
        //public string Toll_fare_calculation_error { get; set; }
        //public string Wrong_Debit_Adjustment_raised { get; set; }
        //public string Other_Specify { get; set; }
        //public string NETC_Toll_services_not_availed_Tag_holder_does_not_recognise_the_transaction { get; set; }
        //public string Fraudulent_multiple_transaction { get; set; }
        //public string Signature_not_validated { get; set; }
        //public string Total { get; set; }
    }
    #region DashBoardSummary
    void LinkDashBoard_Click()
    {
        DataTable dt = new DataTable();

        dt.Columns.Add("tablehtml", typeof(string));
        dt.Columns.Add("iUser", typeof(int));
       
        dt.Rows.Add("<html><table border = 1 style = 'border-color: #908686;'><tr><td colspan = '10' style = 'padding-left:6px' Bgcolor = '#e6f5ff'> Transaction Summary for  06 Jul 2020 </td><td colspan = '10' Bgcolor = '#e6f5ff'> Count </td></tr></table></html>", 63);

        
        string report = "";
        

        if (dt.Rows.Count > 0)
        {
            report = dt.Rows[0][0].ToString();
            view.InnerHtml = report;
        }

    }
    #endregion


    #region DashBoardSummary
    //void LinkDashBoardTollFieTable()
    //{
    //    string user = Convert.ToString(Session["iUser"]);
    //    _bll.User = Convert.ToString(Session["iUser"]);

    //    string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
    //    SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));
    //    SqlCommand cmd = new SqlCommand("Usp_Toll_File_Summary_Table_new", con);
    //    cmd.CommandTimeout = 240;
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    cmd.Parameters.AddWithValue("@iUser", user);
    //    SqlDataAdapter da = new SqlDataAdapter(cmd);
    //    da.Fill(dt);

    //    if (dt.Rows.Count > 0)
    //    {
    //        //gdTollFile.DataSource=dt;
    //        //gdTollFile.DataBind();


    //    }

    //}
    #endregion

}