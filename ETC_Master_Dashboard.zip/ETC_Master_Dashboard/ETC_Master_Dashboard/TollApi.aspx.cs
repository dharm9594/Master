﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using System.Collections;

public partial class TollApi : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        Response.Cache.SetNoStore();
        Response.Cache.SetCacheability(HttpCacheability.NoCache);

        string ASPSession = null;
        string BASPSession = null;
        if (System.Web.HttpContext.Current.Session["ASPSession"] != null)
        {
            ASPSession = Session["ASPSession"].ToString();
        }
        if (Request.Cookies["ASP.NET_SessionId"] != null)
        {
            BASPSession = Request.Cookies["ASP.NET_SessionId"].Value;
        }
        if (BASPSession == ASPSession)
        {
            string SessionAuth = null;
            if (System.Web.HttpContext.Current.Session["AuthToken"] != null)
            {
                SessionAuth = Session["AuthToken"].ToString();
            }
            string auth = null;
            if (Request.Cookies["MPor_AuthToken"] != null)
            {
                auth = Request.Cookies["MPor_AuthToken"].Value;
            }
            if (SessionAuth == auth)
            {

                if (Session["DisplayName"] != null)
                {
                    if (!IsPostBack)
                    {

                    }
                }
            }
            else
            {
                Response.Redirect("LogInNewPage.aspx");
            }
        }
        else
        {
            Response.Redirect("LogInNewPage.aspx");
        }

    }
    [System.Web.Services.WebMethod]
    public static List<SubMenu> Search(string search)
    {
        int iUser = Convert.ToInt32(HttpContext.Current.Session["iUser"]);
        DataTable dt = new DataTable();

        List<SubMenu> AllMenu = new List<SubMenu>();
        dt = (DataTable)HttpContext.Current.Session["MainTable"];
        DataRow[] fd = dt.Select("depth not in (0) and iUser = " + iUser + " and MenuName LIKE '%" + search + "%'");

        SubMenu sm = new SubMenu();
        for (int i = 0; i < fd.Length; i++)
        {
            sm.MenuName = Convert.ToString(fd[i]["MenuName"]);
            sm.iMenu = Convert.ToInt32(fd[i]["iMenu"]);
            sm.Menu_Url = Convert.ToString(fd[i]["MenuUrl"]);
            AllMenu.Add(sm);
        }
        return AllMenu;

    }
    public class SubMenu
    {
        public int iMenu { get; set; }
        public string MenuName { get; set; }
        public string Menu_Url { get; set; }
    }

    [System.Web.Services.WebMethod]
    public static int Set_Fav_Menu(string favMenuName, string heartIcon)
    {
        int status, count, err;
        DataTable dt = new DataTable();
        DataTable dt1 = new DataTable();
        int iUser = Convert.ToInt32(HttpContext.Current.Session["iUser"]);
        dt = (DataTable)HttpContext.Current.Session["MainTable"];
        if (heartIcon == "right fa fa-heart fa-heart-o")
        {
            DataRow[] fd3 = dt.Select(" HeartMenuIcon = 'right fa fa-heart fa-heart-o' and iUser = " + iUser);
            dt1 = fd3.CopyToDataTable();
            count = Convert.ToInt32(dt1.Compute("Count(HeartMenuIcon)", string.Empty));
            if (count >= 5)
            {
                err = 1;
            }
            else
            {
                DataRow[] fd1 = dt.Select(" MenuName = '" + favMenuName + "' and iUser = " + iUser);

                foreach (DataRow dr in fd1)
                {
                    dr["HeartMenuIcon"] = "right fa fa-heart fa-heart-o";
                    dt.AcceptChanges();
                    dr.SetModified();
                    //dr.SetField("HeartMenuIcon", heartIcon);
                }
                err = 0;
                HttpContext.Current.Session["MainTable"] = dt;
            }
        }
        else
        {
            DataRow[] fd1 = dt.Select(" MenuName = '" + favMenuName + "' and iUser = " + iUser);

            foreach (DataRow dr in fd1)
            {
                dr["HeartMenuIcon"] = heartIcon;
                dt.AcceptChanges();
                dr.SetModified();
                //dr.SetField("HeartMenuIcon", heartIcon);
            }
            HttpContext.Current.Session["MainTable"] = dt;
            err = 0;
        }

        return err;

    }
    [System.Web.Services.WebMethod]
    public static string GetDataForGraph()
    {
        try
        {
           
            List<graph> objTransactionReportList = new List<graph>();//collection
            graph objTransactionReport;
            DataTable dt = new DataTable();
            dt.Columns.Add("id", typeof(int));
            dt.Columns.Add("totalTime", typeof(DateTime));
            dt.Columns.Add("totalcnt", typeof(int));
            dt.Columns.Add("success_cnt", typeof(int));
            dt.Columns.Add("decline_cnt", typeof(int));
            dt.Columns.Add("color", typeof(string));

            dt.Rows.Add(1, "04:50:00", 250, 20, 3, "#009900");

            dt.Rows.Add(3, "05:00:00", 150, 10, 1, "#FF0000");
            dt.Rows.Add(6, "05:10:00", 450, 7, 5, "#0000FF");
            dt.Rows.Add(6, "05:20:00", 450, 0, 5, "#FF33FF");
            dt.Rows.Add(2, "05:30:00", 750, 70, 51, "#33FFFF");

            for (int Count = 0; Count < dt.Rows.Count; Count++)
            {
                objTransactionReport = new graph();
                objTransactionReport.totalTime = Convert.ToString(dt.Rows[Count]["totalTime"]);
                objTransactionReport.totalcnt = Convert.ToString(dt.Rows[Count]["totalcnt"]);
                objTransactionReport.success_cnt = Convert.ToString(dt.Rows[Count]["success_cnt"]);
                objTransactionReport.decline_cnt = Convert.ToString(dt.Rows[Count]["decline_cnt"]);
                objTransactionReport.color = Convert.ToString(dt.Rows[Count]["color"]);

                objTransactionReportList.Add(objTransactionReport);
            }
            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(objTransactionReportList);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    [System.Web.Services.WebMethod]
    public static string GetDataForGraph_()
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));
            SqlCommand cmd = new SqlCommand("Usp_FinancialSummaryChart", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@iUser", user);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt); //comment
            con.Close();

            List<graph> objTransactionReportList = new List<graph>();//collection
            graph objTransactionReport;

            for (int Count = 0; Count < dt.Rows.Count; Count++)
            {
                objTransactionReport = new graph();
                objTransactionReport.totalTime = Convert.ToString(dt.Rows[Count]["totalTime"]);
                objTransactionReport.totalcnt = Convert.ToString(dt.Rows[Count]["totalcnt"]);
                objTransactionReport.success_cnt = Convert.ToString(dt.Rows[Count]["success_cnt"]);
                objTransactionReport.decline_cnt = Convert.ToString(dt.Rows[Count]["decline_cnt"]);

                objTransactionReportList.Add(objTransactionReport);
            }
            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(objTransactionReportList);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    [System.Web.Services.WebMethod]
    public static string GetDataForTransactionReport(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataSet dt = new DataSet();
            DataSet ds = new DataSet();
            MessageBox.Show(DateTime.Today.ToString("yyyy-mm-dd hh:mm:ss"));
            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Trans_Details", con);
            cmd.CommandTimeout = 300;
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iuser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            MessageBox.Show(DateTime.Today.ToString("yyyy-mm-dd hh:mm:ss"));
            foreach (DataColumn dc in dt.Tables[0].Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }
            string str = dt.Tables[0].Rows.Count.ToString();
            con.Close();

            //List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            //Dictionary<string, object> row;
            //foreach (DataRow dr in dt.Rows)
            //{
            //    row = new Dictionary<string, object>();
            //    foreach (DataColumn col in dt.Columns)
            //    {
            //        row.Add(col.Caption, dr[col]);
            //    }
            //    rows.Add(row);
            //}

            //JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            //jSearializer.MaxJsonLength = Int32.MaxValue;
            //return jSearializer.Serialize(rows);




            JavaScriptSerializer jsSerializer = new JavaScriptSerializer();
            // var lst = dt.AsEnumerable().Select(r => r.Table.Columns.Cast<DataColumn>().Select(c => new KeyValuePair<string, object>(c.ColumnName, r[c.Ordinal])).ToDictionary(z => z.Key, z => z.Value)).ToList();
            //   int ss = Int64.MaxValue;
            var lst = str;
            jsSerializer.MaxJsonLength = 999999999;
            return jsSerializer.Serialize(lst);

            // return DataSetExt.GetJSON(dt);



        }
        catch (Exception ex)
        {
            throw ex;
        }



    }


    [System.Web.Services.WebMethod]
    public static string GetDataForBlacklistTransactionReport(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataSet dt = new DataSet();
            DataSet ds = new DataSet();
            MessageBox.Show(DateTime.Today.ToString("yyyy-mm-dd hh:mm:ss"));
            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Trans_Details_ETCSBI", con);
            cmd.CommandTimeout = 300;
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iuser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            MessageBox.Show(DateTime.Today.ToString("yyyy-mm-dd hh:mm:ss"));
            foreach (DataColumn dc in dt.Tables[0].Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }
            string str = dt.Tables[0].Rows.Count.ToString();
            con.Close();

            //List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            //Dictionary<string, object> row;
            //foreach (DataRow dr in dt.Rows)
            //{
            //    row = new Dictionary<string, object>();
            //    foreach (DataColumn col in dt.Columns)
            //    {
            //        row.Add(col.Caption, dr[col]);
            //    }
            //    rows.Add(row);
            //}

            //JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            //jSearializer.MaxJsonLength = Int32.MaxValue;
            //return jSearializer.Serialize(rows);




            JavaScriptSerializer jsSerializer = new JavaScriptSerializer();
            // var lst = dt.AsEnumerable().Select(r => r.Table.Columns.Cast<DataColumn>().Select(c => new KeyValuePair<string, object>(c.ColumnName, r[c.Ordinal])).ToDictionary(z => z.Key, z => z.Value)).ToList();
            //   int ss = Int64.MaxValue;
            var lst = str;
            jsSerializer.MaxJsonLength = 999999999;
            return jsSerializer.Serialize(lst);

            // return DataSetExt.GetJSON(dt);



        }
        catch (Exception ex)
        {
            throw ex;
        }



    }
    [System.Web.Services.WebMethod]
    public static string GetDataforTranSearch(string Tollid, string fromDate, string toDate, string Type, string TagId, string AgencyTxnId)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Trans_Search", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 300;
            cmd.Parameters.AddWithValue("@iUser", user);
            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);
            cmd.Parameters.AddWithValue("@Type", Type);
            cmd.Parameters.AddWithValue("@TagId", TagId);
            cmd.Parameters.AddWithValue("@AgencyTxnId", AgencyTxnId);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');

            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);
        }
        catch (Exception)
        {
            throw;
        }
    }


    [System.Web.Services.WebMethod]
    public static string GetDataforSFTPLogs(string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_sftp_logs", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 300;
            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');

            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);
        }
        catch (Exception)
        {
            throw;
        }
    }


    [System.Web.Services.WebMethod]
    public static string GetDataforTollFileExchange(string Tollid, string fromDate, string toDate, string Type, string FileName)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            string RbType = "0";

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Toll_File_BLT", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 300;
            cmd.Parameters.AddWithValue("@iUser", user);
            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);
            cmd.Parameters.AddWithValue("@Type", Type);
            cmd.Parameters.AddWithValue("@FileName", FileName);
            cmd.Parameters.AddWithValue("@RbType", RbType);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                HttpContext.Current.Session["DataExchange"] = dt;
            }

            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');

            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);
        }
        catch (Exception)
        {
            throw;
        }
    }




    [System.Web.Services.WebMethod]
    public static string GetDataforTranFile(string FileName)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            string RbType = "0";

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_Toll_File_Tran_GetData", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 300;
            cmd.Parameters.AddWithValue("@SourceFileName", FileName);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                HttpContext.Current.Session["DataTransaction"] = dt;
            }
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');

            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);
        }
        catch (Exception)
        {
            throw;
        }
    }

    [System.Web.Services.WebMethod]
    public static string GetDataForTransactionReportAllInOne(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_AllInOne_Trans_Details", con);
            // cmd.CommandTimeout = 120;
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iuser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }



    }

    [System.Web.Services.WebMethod]
    public static string GetActivePassess(string Tollid)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Monthly_Pass_Details_Active", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@iUser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);


            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }

    [System.Web.Services.WebMethod]
    public static string GetLocalReport(string Tollid, string status, string tag_id)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Local_Pass_Report", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@iUser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);
            cmd.Parameters.AddWithValue("@status", status);
            cmd.Parameters.AddWithValue("@tag_id", tag_id);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }



    [System.Web.Services.WebMethod]
    public static string GetDataForMonthlyPassIssuanceReport2(string PassType, string reportType, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));
            SqlCommand cmd = new SqlCommand("Usp_get_Monthly_Pass_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@iuser", user);
            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@report_type", reportType);
            cmd.Parameters.AddWithValue("@pass_type", PassType);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');

            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);

        }
        catch (Exception)
        {
            throw;
        }


    }



    [System.Web.Services.WebMethod]
    public static string GetDataForDeclinedTransactionReport(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Declined_Trans_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iuser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }

    [System.Web.Services.WebMethod]
    public static string GetDataForCreditSettlementReport(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Credit_Settlement_Report", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iUser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }

    [System.Web.Services.WebMethod]
    public static string GetDataForTollFileSummary(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_Toll_File_Summary", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@StartDate", fromDate);
            cmd.Parameters.AddWithValue("@EndDate", toDate);
            cmd.Parameters.AddWithValue("@iUser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }

    [System.Web.Services.WebMethod]
    public static string GetDataForMonthlyPassReport(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Monthly_Trans_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iuser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }

    [System.Web.Services.WebMethod]
    public static string GetDataForTransactionReportInternal(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_TransInternal_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iUser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }

    [System.Web.Services.WebMethod]
    public static string GetDataForVRCTransactionReport(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_VRCTrans_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iuser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<VRCTransactionReport> objVRCTransactionReportList = new List<VRCTransactionReport>();//collection
            VRCTransactionReport objVRCTransactionReport;

            for (int Count = 0; Count < dt.Rows.Count; Count++)
            {
                objVRCTransactionReport = new VRCTransactionReport();
                objVRCTransactionReport.file_txn_id = Convert.ToString(dt.Rows[Count]["file_txn_id"]);
                objVRCTransactionReport.txn_id = Convert.ToString(dt.Rows[Count]["txn_id"]);
                objVRCTransactionReport.conn_txn_time = Convert.ToString(dt.Rows[Count]["conn_txn_time"]);
                objVRCTransactionReport.tran_amount = Convert.ToString(dt.Rows[Count]["tran_amount"]);
                objVRCTransactionReport.req_in = Convert.ToString(dt.Rows[Count]["req_in"]);
                objVRCTransactionReport.acc_amount = Convert.ToString(dt.Rows[Count]["acc_amount"]);
                objVRCTransactionReport.vehicle_reg_no = Convert.ToString(dt.Rows[Count]["vehicle_reg_no"]);
                objVRCTransactionReport.AVC_Amount = Convert.ToString(dt.Rows[Count]["AVC_Amount"]);
                objVRCTransactionReport.avc = Convert.ToString(dt.Rows[Count]["avc"]);
                objVRCTransactionReport.Tag_Class = Convert.ToString(dt.Rows[Count]["Tag_Class"]);
                objVRCTransactionReport.Mapper_Class = Convert.ToString(dt.Rows[Count]["Mapper_Class"]);
                objVRCTransactionReport.mvcavc = Convert.ToString(dt.Rows[Count]["mvcavc"]);
                //objVRCTransactionReport.vehicle_class = Convert.ToString(dt.Rows[Count]["vehicle_class"]);
                objVRCTransactionReport.vehicle_tag_id = Convert.ToString(dt.Rows[Count]["vehicle_tag_id"]);
                objVRCTransactionReport.tran_status = Convert.ToString(dt.Rows[Count]["tran_status"]);
                objVRCTransactionReport.journey_type = Convert.ToString(dt.Rows[Count]["journey_type"]);
                objVRCTransactionReport.RSPC_Desc = Convert.ToString(dt.Rows[Count]["RSPC_Desc"]);
                objVRCTransactionReport.settleDate = Convert.ToString(dt.Rows[Count]["settleDate"]);
                objVRCTransactionReport.is_image_uploaded = Convert.ToString(dt.Rows[Count]["is_image_uploaded"]);
                objVRCTransactionReport.img_wide_range = Convert.ToString(dt.Rows[Count]["img_wide_range"]);
                objVRCTransactionReport.img_rear_view = Convert.ToString(dt.Rows[Count]["img_rear_view"]);
                objVRCTransactionReport.Toll_Name = Convert.ToString(dt.Rows[Count]["Toll_Name"]);
                objVRCTransactionReportList.Add(objVRCTransactionReport);
            }
            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(objVRCTransactionReportList);





        }
        catch (Exception)
        {
            throw;
        }
    }

    [System.Web.Services.WebMethod]
    public static string GetDataForAutoDebitAdjustmentReport(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Auto_Debit_Adjustment", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iUser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }


    [System.Web.Services.WebMethod]
    public static string GetDataForDebitAdjustment(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_DebitAdjustment_Report", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iUser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }



    [System.Web.Services.WebMethod]
    public static string GetDataForNonVRCTransactionReport(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_NonViolationTrans_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iuser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }



    [System.Web.Services.WebMethod]
    public static string GetDataForMonthlyPassIssuanceReport(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Monthly_Pass_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iuser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }

    [System.Web.Services.WebMethod]
    public static string GetDataForMonthlyPassIssuanceReportforSBIepay(string reportType, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Monthly_Pass_ReportForSBIePay", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iuser", user);
            cmd.Parameters.AddWithValue("@report_type", reportType);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }


    [System.Web.Services.WebMethod]
    public static string GetDataForReconReport(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);

            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Recon_Details_New", con);

            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iUser", user);
            MessageBox.Show(user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');

            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);

        }
        catch (Exception)
        {
            throw;
        }

    }

    [System.Web.Services.WebMethod]
    public static string GetDataForTerrifReport(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_generate_Fare_Report", con);
            cmd.CommandType = CommandType.StoredProcedure;

            //cmd.Parameters.AddWithValue("@sDate", fromDate);
            //cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iuser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);
            //cmd.Parameters.AddWithValue("@ddlName", reportType);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }


    [System.Web.Services.WebMethod]
    public static string GetDataForRevenueReport(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Revenue_Report", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iuser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }

    [System.Web.Services.WebMethod]
    public static string GetDataForTranReconSettlementReport(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Tran_Recon_Settlement_Report", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iuser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;

            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }


            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }

    [System.Web.Services.WebMethod]
    public static string GetDataForTranReconSettlementReportInternal(string Tollid, string fromDate, string toDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_Tran_recon_Settlement_ReportInternal", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iUser", user);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }

    [System.Web.Services.WebMethod]
    public static string GetDataForChargeBackReport(string Tollid, string fromDate, string toDate, string ReportType)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();

            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            SqlCommand cmd = new SqlCommand("Usp_get_ChargeBack_Report_Updated", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@sDate", fromDate);
            cmd.Parameters.AddWithValue("@eDate", toDate);
            cmd.Parameters.AddWithValue("@iUser", user);
            cmd.Parameters.AddWithValue("@ReportType", ReportType);
            cmd.Parameters.AddWithValue("@toll_id", Tollid);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            foreach (DataColumn dc in dt.Columns)
            {
                dc.Caption = dc.ColumnName.Replace('_', ' ');
                if (dc.Caption.Contains("Rs"))
                    dc.Caption = dc.Caption.Replace('.', ' ');
            }

            con.Close();

            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.Caption, dr[col]);
                }
                rows.Add(row);
            }

            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(rows);




        }
        catch (Exception)
        {
            throw;
        }
    }



    [System.Web.Services.WebMethod]
    public static string GetDataForFinancialReport(string fromDate)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);

            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            List<DataReport> objDataReportList = new List<DataReport>();//collection
            DataReport objTransactionReport;
            SqlCommand cmd = new SqlCommand("Usp_ChckFileUpload", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@StartDate", fromDate);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            con.Close();
            if (!object.Equals(dt.Rows, null))
            {
                if (dt.Rows.Count > 0)
                {
                    for (int j = 0; j < dt.Rows.Count; j++)
                    {
                        objTransactionReport = new DataReport();
                        objTransactionReport.FileName = Convert.ToString(dt.Rows[j]["FileName"]);
                        objDataReportList.Add(objTransactionReport);
                    }

                }
            }
            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(objDataReportList);




        }
        catch (Exception)
        {
            throw;
        }

    }


    [System.Web.Services.WebMethod]
    public static string CheckPassExpiry(string TagID)
    {
        try
        {
            string user = Convert.ToString(HttpContext.Current.Session["iUser"]);

            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            string _connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["conString"]);
            //string decode = DAL.Base64Decode(_connectionstring);
            SqlConnection con = new SqlConnection(DAL.Base64Decode(_connectionstring));

            List<CheckPass> objDataReportList = new List<CheckPass>();//collection
            CheckPass objTransactionReport;
            SqlCommand cmd = new SqlCommand("Usp_check_montlypass_expiry", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@TagID", TagID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            con.Close();
            if (!object.Equals(dt.Rows, null))
            {
                if (dt.Rows.Count > 0)
                {
                    for (int j = 0; j < dt.Rows.Count; j++)
                    {
                        objTransactionReport = new CheckPass();
                        objTransactionReport.TagID = Convert.ToString(dt.Rows[0][0]);
                        objDataReportList.Add(objTransactionReport);
                    }

                }
            }
            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            jSearializer.MaxJsonLength = Int32.MaxValue;
            return jSearializer.Serialize(objDataReportList);




        }
        catch (Exception)
        {
            throw;
        }



    }

    public class CheckPass
    {
        public string TagID { get; set; }

    }


    public class DataReport
    {
        public string FileName { get; set; }

    }
    public class graph
    {
        public string totalTime { get; set; }
        public string totalcnt { get; set; }
        public string success_cnt { get; set; }
        public string decline_cnt { get; set; }
        public string color { get; set; }
    }


    public class VRCTransactionReport
    {
        public string file_txn_id { get; set; }
        public string txn_id { get; set; }
        public string toll_id { get; set; }
        public string conn_txn_time { get; set; }
        public string tran_amount { get; set; }
        public string req_in { get; set; }
        public string acc_amount { get; set; }
        public string vehicle_reg_no { get; set; }
        public string AVC_Amount { get; set; }
        public string avc { get; set; }
        public string Tag_Class { get; set; }
        public string Mapper_Class { get; set; }
        public string mvcavc { get; set; }
        public string vehicle_class { get; set; }
        public string vehicle_tag_id { get; set; }
        public string tran_status { get; set; }
        public string journey_type { get; set; }
        public string RSPC_Desc { get; set; }
        public string settleDate { get; set; }
        public string is_image_uploaded { get; set; }
        public string img_wide_range { get; set; }
        public string img_rear_view { get; set; }
        public string Toll_Name { get; set; }

    }




}
public static class DataSetExt
{
    public static string GetJSON(this DataSet ds)
    {

        System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
        ArrayList root = new ArrayList();
        List<Dictionary<string, object>> table;
        Dictionary<string, object> data;

        foreach (DataTable dt in ds.Tables)
        {
            table = new List<Dictionary<string, object>>();
            foreach (DataRow dr in dt.Rows)
            {
                data = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    data.Add(col.ColumnName, dr[col]);
                }
                table.Add(data);
            }
            root.Add(table);
        }

        return serializer.Serialize(root);
    }
}