﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    int iUser = 1;

    DataTable dtChild = new DataTable();
    DataTable MenuTable = new DataTable();
    
    protected void Page_Load(object sender, EventArgs e)
    {
        //Response.Cache.SetNoStore();
        //Response.Cache.SetCacheability(HttpCacheability.NoCache);

        //string ASPSession = null;
        //string BASPSession = null;
        //if (System.Web.HttpContext.Current.Session["ASPSession"] != null)
        //{
        //    ASPSession = Session["ASPSession"].ToString();
        //}
        //if (Request.Cookies["ASP.NET_SessionId"] != null)
        //{
        //    BASPSession = Request.Cookies["ASP.NET_SessionId"].Value;
        //}
        //if (BASPSession == ASPSession)
        //{
        //    string SessionAuth = null;
        //    if (System.Web.HttpContext.Current.Session["AuthToken"] != null)
        //    {
        //        SessionAuth = Session["AuthToken"].ToString();
        //    }
        //    string auth = null;
        //    if (Request.Cookies["MPor_AuthToken"] != null)
        //    {
        //        auth = Request.Cookies["MPor_AuthToken"].Value;
        //    }
        //    if (SessionAuth == auth)
        //    {
        //        if (Session["DisplayName"] != null)
        //        {

        //            if (!IsPostBack)
        //            {
        //                lblUser.InnerText = Convert.ToString(Session["DisplayName"]);

        //                lblLastLogin.InnerText = Convert.ToString(Session["LastLogin"]);

        //            }
        //        }

        //        else
        //        {
        //            Response.Redirect("LogInNewPage.aspx");
        //        }
        //    }
        //    else
        //    {
        //        Response.Redirect("LogInNewPage.aspx");
        //    }
        //}
        //else
        //{
        //    Response.Redirect("LogInNewPage.aspx");
        //}

        if (!this.IsPostBack)
        {
            Session["iUser"] = iUser;
            //lblUser.InnerText = "ETC Admin";
            lblUser.InnerText = Convert.ToString(Session["DisplayName"]);
            //lblLastLogin.InnerText = DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt");
            // lblLastLogin.InnerText = Convert.ToString(Session["test"]);
              lblLastLogin.InnerText = Convert.ToString(Session["LastLogin"]);

            
            MenuTable.Columns.Add("iMenu", typeof(int));
            MenuTable.Columns.Add("depth", typeof(int));
            MenuTable.Columns.Add("MenuName", typeof(string));
            MenuTable.Columns.Add("MenuUrl", typeof(string));

            
            MenuTable.Columns.Add("MenuIcon", typeof(string));
            MenuTable.Columns.Add("HeartMenuIcon", typeof(string));
            MenuTable.Columns.Add("iUser", typeof(int));
            MenuTable.Columns.Add("Enable", typeof(int));

            MenuTable.Rows.Add(1, 0, "Reports", null, "fa fa-file nav-icon", null, 1, 1);
            MenuTable.Rows.Add(2, 0, "Upload", null, "fa fa-upload nav-icon", null, 1, 1);
            MenuTable.Rows.Add(3, 0, "other", null, "fas fa-circle nav-icon", null, 1, 1);
            MenuTable.Rows.Add(4, 1, "Active Monthly Pass", "ActiveMonthlyPass.aspx", null, "right fa fa-heart fa-heart-o", 1, 1);
            MenuTable.Rows.Add(5, 2, "Upload ECGS File", "UploadECGSFile.aspx", null, "right fa fa-heart", 1, 1);
            MenuTable.Rows.Add(6, 1, "Farelist Report", "FarelistReport.aspx", null, "right fa fa-heart fa-heart-o", 1, 1);
            MenuTable.Rows.Add(7, 0, "Data Exchange", "DataExchange.aspx", "fa fa-exchange nav-icon", "null ", 2, 1);
            MenuTable.Rows.Add(8, 0, "Search Option", "#", "fa fa-search nav-icon", "null ", 2, 1);
            MenuTable.Rows.Add(9, 8, "BlackList Search", "BlackList.aspx", null, "right fa fa-heart", 2, 1);
            MenuTable.Rows.Add(10, 8, "Transaction Search", "Transaction.aspx", null, "right fa fa-heart fa-heart-o", 2, 1);
            MenuTable.Rows.Add(11, 0, "All Pass Issuance", "#", "fa fa-ticket nav-icon", null, 2, 1);
            MenuTable.Rows.Add(12, 11, "Pass Issuance", "PassIssuance.aspx", null, "right fa fa-heart", 2, 1);
            Session["MainTable"] = MenuTable;
            this.BindMenu();
            this.BindImpMenu();
        }
    }
    
    protected void rptMenu_OnItemBound(object sender, RepeaterItemEventArgs e)
    {
        DataTable dtParent = new DataTable();
        dtParent = (DataTable)Session["MainTable"];
        DataTable dc = new DataTable();
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            Repeater rptSubMenu = e.Item.FindControl("rptChildMenu") as Repeater;
            DataRow[] fd = dtParent.Select(" depth = " + ((System.Data.DataRowView)(e.Item.DataItem)).Row[0] + " and iUser = " + iUser + "and Enable = 1");
            if (fd.Length > 0)
            {

                dc = fd.CopyToDataTable();

            }
            else
            {
                ((HtmlGenericControl)(e.Item.FindControl("angleicon"))).Attributes["class"] = "";

            }
            if (dc.Rows.Count > 0)
            {
                rptSubMenu.DataSource = dc;

                rptSubMenu.DataBind();
            }
        }
    }



    private void BindMenu()
    {
        DataTable dt = new DataTable();
        DataTable dtParent = new DataTable();
        dtParent = (DataTable)Session["MainTable"];
        DataRow[] fd = dtParent.Select(" depth = 0 and iUser = " + iUser + "and Enable = 1");
        dt = fd.CopyToDataTable();
        this.rptMenu.DataSource = dt;

        this.rptMenu.DataBind();
    }
    
    public void BindImpMenu()
    {
        DataTable dt1 = new DataTable();
        DataTable dt = new DataTable();
        dt = (DataTable)Session["MainTable"];
        DataRow[] fd = dt.Select(" HeartMenuIcon = 'right fa fa-heart fa-heart-o' and iUser = " + iUser + "and Enable = 1");
        dt1 = fd.CopyToDataTable();
        
        if (dt1.Rows.Count > 0)
        {
            this.rptImpMenu.DataSource = dt1;
            this.rptImpMenu.DataBind();
        }

        
    }
    
    protected void lblLogOut(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("LogInNewPage.aspx");
    }
}


