﻿function GetTransactionSummary(Tollid, fromDate, toDate) {
    
    var Tollid = Tollid;
    var fromDate = fromDate;
    var toDate = toDate;

    var x = "TollApi.aspx/";
    var y = "GetTransactionSummary";
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'Tollid': '" + Tollid + "','fromDate': '" + fromDate + "','toDate': '" + toDate + "'}",
        dataType: "json",
        success: SuccesGetDataForTransactionReport,
        error: ErrorResponse
    });
}

function GetDataforTollFiles(Tollid, fromDate, toDate) {
    
    var Tollid = Tollid;
    var fromDate = fromDate;
    var toDate = toDate;

    var x = "TollApi.aspx/";
    var y = "GetDataforTollFiles";
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'Tollid': '" + Tollid + "','fromDate': '" + fromDate + "','toDate': '" + toDate + "'}",
        dataType: "json",
        success: SuccesGetDataForTransactionReport,
        error: ErrorResponse
    });
}

function GetDataforDashboardHistoic(Tollid, fromDate, toDate, Operation) {
    
    var Tollid = Tollid;
    var fromDate = fromDate;
    var toDate = toDate;
    var Operation = Operation;


    var x = "TollApi.aspx/";
    var y = "GetDataforDashboardHistoric";
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'Tollid': '" + Tollid + "','fromDate': '" + fromDate + "','toDate': '" + toDate + "','Operation': '" + Operation + "'}",
        dataType: "json",
        success: SuccesGetDataForTransactionReport,
        error: ErrorResponse
    });
}

function GetDataforCBK(Tollid, disputetype, fromDate, toDate) {
    $(".container-fluid").css("opacity", 0.2);
    $("#loaderDiv").css("display", "block");
    $("#btnSearch").attr("disabled", "disabled");

   

    var Tollid = Tollid;
    var disputetype = disputetype;
    var fromDate = fromDate;
    var toDate = toDate;


    var x = "TollApi.aspx/";
    var y = "GetDataforCBK";
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'Tollid': '" + Tollid + "','disputetype': '" + disputetype + "','fromDate': '" + fromDate + "','toDate': '" + toDate + "'}",
        dataType: "json",
        success: SuccesGetDataForTransactionReport,
        error: ErrorResponse
    });
}

function Chkpassexpiry() {
    //debugger;
    var x = "TollApi.aspx/";
    var y = "CheckPassExpiry";
    var TagID = $("#ContentPlaceHolder1_txtTagId").val();
   

//    $("#ContentPlaceHolder1_btnSearch").attr("disabled", "disabled");
//    $('#ContentPlaceHolder1_btnSearch').val('Please wait..');
    //debugger;
    $.ajax({

        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'TagID': '" + TagID + "'}",
        dataType: "json",
        success: function (data) {
            //alert(data.d);
            var objTransactionReport = data.d;
            var objTransactionReport = JSON.parse(data.d);
            //alert(objTransactionReport);
            if (objTransactionReport.length >= 1) {
                //alert(objTransactionReport[0].TagID)
                var msg = objTransactionReport[0].TagID;
                confirm();
                //alert("confirm " + msg);
                //                alert("ajax" + msg);



            }

        },
        error: function (err) { alert(err); }
    });
}

function Confirm() {
    var confirm_value = document.createElement("INPUT");
    confirm_value.type = "hidden";
    confirm_value.name = "confirm_value";
    if (confirm("Do you want to save data?")) {
        confirm_value.value = "Yes";
    } else {
        confirm_value.value = "No";
    }
    document.forms[0].appendChild(confirm_value);
}

function ChkFileUpload() {
    //debugger;



    var x = "TollApi.aspx/";
    var y = "GetDataForFinancialReport";
    var fromDate = $("#ContentPlaceHolder1_txtDate").val();

    $("#ContentPlaceHolder1_btnSearch").attr("disabled", "disabled");
    $('#ContentPlaceHolder1_btnSearch').val('Please wait..');

    $.ajax({
       
         type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'fromDate': '" + fromDate +"'}",
        dataType: "json",
        success: function (data, status) {
	
	var objTransactionReport =JSON.parse(data.d);
		//alert(objTransactionReport);
            if (objTransactionReport.length >= 1) {
                $("#ContentPlaceHolder1_btnSearch").removeAttr("disabled");
                $('#ContentPlaceHolder1_btnSearch').val('Search');
            }
            else {
			
                alert("EGCS File Not Uploded for" + fromDate);
                // $("#ContentPlaceHolder1_btnSearch").removeAttr("disabled");
                $('#ContentPlaceHolder1_btnSearch').val('Search');
                $("#ContentPlaceHolder1_txtDate").val('');
            }

        },
        error: ErrorResponse


    });
}


function Getgraph__()
{

   ////debugger;
    var x = "TollApi.aspx/";
    var y = "GetDataForGraph";
    $.ajax({

        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: {},
        dataType: "json",
        success: SuccesGetDataForGraph,
        error: ErrorResponse
       
        
    });
    function SuccesGetDataForGraph(response) {

        var aData = JSON.parse(response.d);
        var totalcnt = [];
        var time = [];
        var successcnt = [];
        var declinecnt = [];
        var totalTxnCount = 554;

        $.each(aData, function (inx, val) {
            totalcnt.push(val.totalcnt);
            time.push(val.totalTime);
            successcnt.push(val.success_cnt);
            declinecnt.push(val.decline_cnt);
        });
      

        //WidgetChart 1  
        var ctx = document.getElementById("widgetChart1");
        ctx.height = 130;
        var config = {
            type: 'line',
            data: {
                datasets: [{
                    data: totalcnt,
                    label: 'TotalCount',
                    backgroundColor: 'rgba(255,255,255,.1)',
                    borderColor: 'rgba(255,255,255,.55)'
                }],
                labels: time
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                legend: {
                    display: false
                },
                layout: {
                    padding: {
                        left: 0,
                        right: 0,
                        top: 0,
                        bottom: 0
                    }
                },
                scales: {
                    xAxes: [{
                        gridLines: {
                            color: 'transparent',
                            zeroLineColor: 'transparent'
                        },
                        ticks: {
                            fontSize: 2,
                            fontColor: 'transparent'
                        }
                    }],
                    yAxes: [{
                        display: false,
                        ticks: {
                            display: false
                        }
                    }]
                },
                title: {
                    display: false
                },
                elements: {
                    line: {
                        borderWidth: 0
                    },
                    point: {
                        radius: 0,
                        hitRadius: 10,
                        hoverRadius: 4
                    }
                }
            }
        };
       
        var myPieChart = new Chart(ctx, config);

        //WidgetChart 2 
        var ctx = document.getElementById("widgetChart2");
        ctx.height = 130;
        var config = {
            type: 'line',
            data: {
                datasets: [{
                    data: successcnt,
                    label: 'SuccessCount',
                    backgroundColor: 'transparent',
                    borderColor: 'rgba(255,255,255,.55)'
                }],
                labels: time
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                legend: {
                    display: false
                },
                tooltips: {
                    mode: 'index',
                    titleFontSize: 12,
                    titleFontColor: '#000',
                    bodyFontColor: '#000',
                    backgroundColor: '#fff',
                    titleFontFamily: 'Montserrat',
                    bodyFontFamily: 'Montserrat',
                    cornerRadius: 3,
                    intersect: false
                },
                scales: {
                    xAxes: [{
                        gridLines: {
                            color: 'transparent',
                            zeroLineColor: 'transparent'
                        },
                        ticks: {
                            fontSize: 2,
                            fontColor: 'transparent'
                        }
                    }],
                    yAxes: [{
                        display: false,
                        ticks: {
                            display: false
                        }
                    }]
                },
                title: {
                    display: false
                },
                elements: {
                    line: {
                        tension: 0.00001,
                        borderWidth: 1
                    },
                    point: {
                        radius: 4,
                        hitRadius: 10,
                        hoverRadius: 4
                    }
                }
            }
        };
        
        var myPieChart = new Chart(ctx, config);

        //WidgetChart 3 
        var ctx = document.getElementById("widgetChart3");
        ctx.height = 130;
        var config = {
            type: 'line',
            data: {
                datasets: [{
                    data: declinecnt,
                    label: 'DeclineCount',
                    backgroundColor: 'transparent',
                    borderColor: 'rgba(255,255,255,.55)'
                }],
                labels: time
            },
            options: {

                maintainAspectRatio: false,
                legend: {
                    display: false
                },
                responsive: true,
                tooltips: {
                    mode: 'index',
                    titleFontSize: 12,
                    titleFontColor: '#000',
                    bodyFontColor: '#000',
                    backgroundColor: '#fff',
                    titleFontFamily: 'Montserrat',
                    bodyFontFamily: 'Montserrat',
                    cornerRadius: 3,
                    intersect: false
                },
                scales: {
                    xAxes: [{
                        gridLines: {
                            color: 'transparent',
                            zeroLineColor: 'transparent'
                        },
                        ticks: {
                            fontSize: 2,
                            fontColor: 'transparent'
                        }
                    }],
                    yAxes: [{
                        display: false,
                        ticks: {
                            display: false
                        }
                    }]
                },
                title: {
                    display: false
                },
                elements: {
                    line: {
                        borderWidth: 1
                    },
                    point: {
                        radius: 4,
                        hitRadius: 10,
                        hoverRadius: 4
                    }
                }
            }
        };
       
        var myPieChart = new Chart(ctx, config);


        try {
            //WidgetChart 4
            var ctx = document.getElementById("widgetChart4");
            if (ctx) {
                ctx.height = 115;
                var myChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: time,
                        datasets: [
            {
                label: "Toll File",
                data: successcnt,
                borderColor: "transparent",
                borderWidth: "0",
                backgroundColor: "rgba(255,255,255,.3)"
            }
          ]
                    },
                    options: {
                        maintainAspectRatio: true,
                        legend: {
                            display: false
                        },
                        scales: {
                            xAxes: [{
                                display: false,
                                categoryPercentage: 1,
                                barPercentage: 0.65
                            }],
                            yAxes: [{
                                display: false
                            }]
                        }
                    }
                });

            }
        }
        catch (error) {
            console.log(error);
        }
    }
};


function Getgraph() {

    debugger;
    var x = "TollApi.aspx/";
    var y = "GetDataForGraph";
    $.ajax({

        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: {},
        dataType: "json",
        success: SuccesGetDataForGraph,
        error: ErrorResponse


    });
    function SuccesGetDataForGraph(response) {
        debugger;

        var aData = JSON.parse(response.d);
        var totalcnt = [];
        var time = [];
        var successcnt = [];
        var declinecnt = [];
        var color = []
        var totalTxnCount = 554;


        $.each(aData, function (inx, val) {
            totalcnt.push(val.totalcnt);
            time.push(val.totalTime);
            successcnt.push(val.success_cnt);
            declinecnt.push(val.decline_cnt);
            color.push(val.color);


        });
        console.log(color);

        var pieChartCanvas = $('#trans-chart-canvas').get(0).getContext('2d')
        var pieData = {

            datasets: [
                {
                    data: totalcnt,
                    label: 'Total Count',
                    backgroundColor: color,
                }

            ],
            labels: time,
        }
        var pieOptions = {
            legend: {
                display: false
            },
            maintainAspectRatio: false,
            responsive: true,
        }
        //Create pie or douhnut chart
        // You can switch between pie and douhnut using the method below.
        var pieChart = new Chart(pieChartCanvas, {
            type: 'doughnut',
            data: pieData,
            options: pieOptions
        });
        
        //WidgetChart 2 
        var ctx = document.getElementById("widgetChart2");
        ctx.height = 130;
        var config = {
            type: 'line',
            data: {
                datasets: [{
                    data: successcnt,
                    label: 'SuccessCount',
                    backgroundColor: 'transparent',
                    borderColor: 'rgba(255,255,255,.55)'
                }],
                labels: time
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                legend: {
                    display: false
                },
                tooltips: {
                    mode: 'index',
                    titleFontSize: 12,
                    titleFontColor: '#000',
                    bodyFontColor: '#000',
                    backgroundColor: '#fff',
                    titleFontFamily: 'Montserrat',
                    bodyFontFamily: 'Montserrat',
                    cornerRadius: 3,
                    intersect: false
                },
                scales: {
                    xAxes: [{
                        gridLines: {
                            color: 'transparent',
                            zeroLineColor: 'transparent'
                        },
                        ticks: {
                            fontSize: 2,
                            fontColor: 'transparent'
                        }
                    }],
                    yAxes: [{
                        display: false,
                        ticks: {
                            display: false
                        }
                    }]
                },
                title: {
                    display: false
                },
                elements: {
                    line: {
                        tension: 0.00001,
                        borderWidth: 1
                    },
                    point: {
                        radius: 4,
                        hitRadius: 10,
                        hoverRadius: 4
                    }
                }
            }
        };

        var myPieChart = new Chart(ctx, config);
        
        var pieChartCanvas = $('#decline-pie-chart-canvas').get(0).getContext('2d')
        var pieData = {
            labels: time,
            datasets: [
                {
                    data: declinecnt,
                    backgroundColor: color,
                }
            ]
        }
        var pieOptions = {
            legend: {
                display: false
            },
            maintainAspectRatio: false,
            responsive: true,
        }
        //Create pie or douhnut chart
        // You can switch between pie and douhnut using the method below.
        var pieChart = new Chart(pieChartCanvas, {
            type: 'pie',
            data: pieData,
            options: pieOptions
        });


        try {
            //WidgetChart 4
            var ctx = document.getElementById("widgetChart4");
            if (ctx) {
                ctx.height = 130;
                var myChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: time,
                        datasets: [
                            {
                                label: "Toll File",
                                data: successcnt,
                                borderColor: "transparent",
                                borderWidth: "0",
                                backgroundColor: "rgba(255,255,255,.3)"
                            }
                        ]
                    },
                    options: {
                        maintainAspectRatio: true,
                        legend: {
                            display: false
                        },
                        scales: {
                            xAxes: [{
                                display: false,
                                categoryPercentage: 1,
                                barPercentage: 0.65
                            }],
                            yAxes: [{
                                display: false
                            }]
                        }
                    }
                });

            }
        }
        catch (error) {
            console.log(error);
        }
    }
};


function GetDataforChargeBack(Tollid, fromDate, toDate, method,urll)
 {
	$(".container-fluid").css("opacity", 0.2);
    $("#loaderDiv").css("display", "block");
    $("#btnSearch").attr("disabled", "disabled");
	  var Tollid = Tollid;
    var fromDate = fromDate;
    var toDate = toDate;
	var report
	if(urll=="ChargeBack Recovery Report")
	{
		var ReportType="CB Recovery"
	}
	if(urll=="ChargeBack Accepted Report")
	{
		var ReportType="CB Accepted"
	}
	if(urll=="ChargeBack Raised Report")
	{
		var ReportType="CB Raised"
	}
	if(urll=="ChargeBack Representment Report")
	{
		var ReportType="CB Represented"
	}
    var data = { fromDate: fromDate, toDate: toDate, Tollid: Tollid,report:ReportType };

    var x = "TollApi.aspx/";
    var y = method;
    $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: x + y,
            data: "{'fromDate': '" + fromDate + "','toDate': '" + toDate + "','Tollid': '" + Tollid + "','ReportType': '" + ReportType + "'}",
            dataType: "json",
            success: SuccesGetDataForTransactionReport,
            error: ErrorResponse
        });
 }


function GetData(Tollid, fromDate, toDate, method) {
    $(".container-fluid").css("opacity", 0.2);
    $("#loaderDiv").css("display", "block");
    $("#btnSearch").attr("disabled", "disabled");
   
   
    var Tollid = Tollid;
    var fromDate = fromDate;
    var toDate = toDate;
    var data = { fromDate: fromDate, toDate: toDate, Tollid: Tollid };

    var x = "TollApi.aspx/";
    var y = method;
    if (y == "GetDataForVRCTransactionReport") {
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: x + y,
            data: "{'fromDate': '" + fromDate + "','toDate': '" + toDate + "','Tollid': '" + Tollid + "'}",
            dataType: "json",
            success: SuccesGetDataForVRCTransactionReport,
            error: ErrorResponse
        });
    }


    else {
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: x + y,
            data: "{'fromDate': '" + fromDate + "','toDate': '" + toDate + "','Tollid': '" + Tollid + "'}",
            dataType: "json",
            success: SuccesGetDataForTransactionReport,
            error: ErrorResponse
        });
    }
   
}



function GetActivePassess(Tollid) {
    $(".container-fluid").css("opacity", 0.2);
    $("#loaderDiv").css("display", "block");
    $("#btnSearch").attr("disabled", "disabled");

    var Tollid = Tollid;
    
    var data = {  Tollid: Tollid };

    var x = "TollApi.aspx/";
    var y = "GetActivePassess";
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'Tollid': '" + Tollid + "'}",
        dataType: "json",
        success: SuccesGetDataForMonthlyPassActive,
        error: ErrorResponse
    });
}

function GetLocalReport(Tollid,status, tag_id) {
    $(".container-fluid").css("opacity", 0.2);
    $("#loaderDiv").css("display", "block");
    $("#btnSearch").attr("disabled", "disabled");

    var Tollid = Tollid;
    var status = status;
    var tag_id = tag_id;

    var data = { Tollid: Tollid, status: status, tag_id: tag_id  };

    var x = "TollApi.aspx/";
    var y = "GetLocalReport";
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'Tollid': '" + Tollid + "','status': '" + status + "','tag_id': '" + tag_id + "'}",
        dataType: "json",
        success: SuccesGetDataForLocalPassReport,
        error: ErrorResponse
    });
}

function GetDataforTranSearch(Tollid, fromDate, toDate, AgencyTxnId, VechRegNo, TagId, Type) {
    $(".container-fluid").css("opacity", 0.2);
    $("#loaderDiv").css("display", "block");
    $("#btnSearch").attr("disabled", "disabled");

    var Tollid = Tollid;
    var type = Type;
    var tagId = TagId;
    var fromDate = fromDate;
    var toDate = toDate;
    var txnid = AgencyTxnId;
    var VechRegNo = VechRegNo;
 
    var x = "TollApi.aspx/";
    var y = "GetDataforTranSearch";
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'fromDate': '" + fromDate + "','toDate': '" + toDate + "','Type': '" + type + "','TagId': '" + tagId + "','Tollid': '" + Tollid + "','AgencyTxnId': '" + txnid + "' ,'VechRegNo': '" + VechRegNo + "'}",
        dataType: "json",
        success: SuccesGetDataForTransactionReport,
        error: ErrorResponse
    });
}

function GetDataforsftplogs(Tollid, fromDate, toDate) {
    $(".container-fluid").css("opacity", 0.2);
    $("#loaderDiv").css("display", "block");
    $("#btnSearch").attr("disabled", "disabled");

    //debugger;

    var Tollid = Tollid;
    var fromDate = fromDate;
    var toDate = toDate;

    var x = "TollApi.aspx/";
    var y = "GetDataforSFTPLogs";
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'fromDate': '" + fromDate + "','toDate': '" + toDate + "'}",
        dataType: "json",
        success: SuccesGetDataForTransactionReport,
        error: ErrorResponse
    });
}


function GetDataforTollFileExchange(Tollid, fromDate, toDate, FileName,ReportType) {
    $(".container-fluid").css("opacity", 0.2);
    $("#loaderDiv").css("display", "block");
    $("#btnSearch").attr("disabled", "disabled");

    var Tollid = Tollid;
    var type = ReportType;   
    var fromDate = fromDate;
    var toDate = toDate;
    var filename = FileName;
 
    var x = "TollApi.aspx/";
    var y = "GetDataforTollFileExchange";
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'fromDate': '" + fromDate + "','toDate': '" + toDate + "','Type': '" + type + "','FileName': '" + filename + "','Tollid': '" + Tollid + "'}",
        dataType: "json",
        success: SuccesGetDataForTollFileExchange,
        error: ErrorResponse
    });
}


function GetDataforTranFile(FileName) {
    $(".container-fluid").css("opacity", 0.2);
    $("#loaderDiv").css("display", "block");
    $("#btnSearch").attr("disabled", "disabled");

   
    var filename = FileName;
 
    var x = "TollApi.aspx/";
    var y = "GetDataforTranFile";
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'FileName': '" + filename + "'}",
        dataType: "json",
        success: SuccesGetDataForTollFileExchange,
        error: ErrorResponse
    });
}




function SuccesGetDataForTollFileExchange(data, status) {
    
    var objTransactionReportData =JSON.parse(data.d);   
    var TransactionReportData = '';
    console.log(data.d);
  if (objTransactionReportData.length > 0) {
    var my_columns = [];

    $.each(objTransactionReportData[0], function (key, value) {
        var my_item = {};
        my_item.data = key;
        my_item.title = key;
        my_columns.push(my_item);
    });
  $("#grdiDiv").css("display", "block");
    var CreditSettlementReport = '';
    CreditSettlementReport += ' <table id="tblTransactionReport" class="display nowrap dataTable dtr-inline" cellspacing="0" role="grid"  style="border: 1px solid black"  width="100%"></table>';
    $('#dvHTML').html(CreditSettlementReport);
        $('#tblTransactionReport').DataTable(
            {

               "lengthMenu": [[10, 20, 40, -1], [10, 20, 40, "All"]],
                "scrollY": 300,
                "scrollX": true,

                data: objTransactionReportData,
	             "columns": my_columns

	         });

  	$("#loaderDiv").css("display", "none");
	  $(".container-fluid").css("opacity", "unset");	  
      $("#btnSearch").removeAttr("disabled");
      $('#btnSearch').val('Search');
      $('#ShowExport').css('display', 'block');
}
    else {
 	 $("#loaderDiv").css("display", "none");
	  $(".container-fluid").css("opacity", "unset");
	$('#ShowExport').css('display', 'none');
 	$("#btnSearch").removeAttr("disabled");		
        	alert("No Records to Display");

    }
	         
	
	
}


function SuccesGetDataForTransactionReport(data, status) {
    debugger;
    var objTransactionReportData =JSON.parse(data.d);   
    var TransactionReportData = '';
    console.log(data.d);
  if (objTransactionReportData.length > 0) {
    var my_columns = [];

    $.each(objTransactionReportData[0], function (key, value) {
        var my_item = {};
        my_item.data = key;
        my_item.title = key;
        my_columns.push(my_item);
    });
  $("#grdiDiv").css("display", "block");
    var CreditSettlementReport = '';
    CreditSettlementReport += ' <table id="tblTransactionReport" class="display nowrap dataTable dtr-inline" cellspacing="0" role="grid"  style="border: 1px solid black"  width="100%"></table>';
    $('#dvHTML').html(CreditSettlementReport);
        $('#tblTransactionReport').DataTable(
            {

               "lengthMenu": [[15, 25, 50, -1], [15, 25, 50, "All"]],
                "scrollY": 400,
                "scrollX": true,

                data: objTransactionReportData,
	             "columns": my_columns

	         });
}
    else {
  $("#loaderDiv").css("display", "none");
	  $(".container-fluid").css("opacity", "unset");
        alert("No Records to Display");
    }
	         
	
	  $("#loaderDiv").css("display", "none");
	  $(".container-fluid").css("opacity", "unset");	  
      $("#btnSearch").removeAttr("disabled");
      $('#btnSearch').val('Search');
      $('#ShowExport').css('display', 'block');
}

function ErrorResponse(xhr, desc, err) {
    console.log(xhr);
    console.log("Desc: " + desc + "\nErr:" + err);
  $("#loaderDiv").css("display", "none");
	  $(".container-fluid").css("opacity", "unset");	  
      $("#btnSearch").removeAttr("disabled");
      $('#btnSearch').val('Search');
	alert("No Data Available");
    return false;
}


function GetDataForMonthlyPassIssuanceReportforSBIepay(reportType, fromDate, toDate) {
    $(".container-fluid").css("opacity", 0.2);
    $("#loaderDiv").css("display", "block");
   
    var reporttype = reportType;
    var fromDate = fromDate;
    var toDate = toDate;
    var data = { fromDate: fromDate, toDate: toDate, reportType: reporttype };

    var x = "TollApi.aspx/";
    var y = "GetDataForMonthlyPassIssuanceReportforSBIepay";
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'fromDate': '" + fromDate + "','toDate': '" + toDate + "','reportType': '" + reporttype + "'}",
        dataType: "json",
        success: SuccesGetDataForMonthlyPassIssuanceReportforSBIepay,
        error: ErrorResponse
    });
}

function SuccesGetDataForMonthlyPassIssuanceReportforSBIepay(data, status) {
    //alert(data);
    var objTransactionReportData = JSON.parse(data.d);
    var TransactionReportData = '';
    console.log(data.d);
if (objTransactionReportData.length > 0) {
    var my_columns = [];

    $.each(objTransactionReportData[0], function (key, value) {
        var my_item = {};
        my_item.data = key;
        my_item.title = key;
        my_columns.push(my_item);
    });
 $("#grdiDiv").css("display", "block");
    var CreditSettlementReport = '';
    CreditSettlementReport += ' <table id="tblTransactionReport" class="display nowrap dataTable dtr-inline" cellspacing="0" role="grid"  style="border: 1px solid black"  width="100%"></table>';
    $('#dvMonthly').html(CreditSettlementReport);
    $('#tblTransactionReport').DataTable(
            {

                "lengthMenu": [[15, 25, 50, -1], [15, 25, 50, "All"]],
                "scrollY": 400,
                "scrollX": true,
                data: objTransactionReportData,
                "columns": my_columns

            });

}
    else {
  $("#loaderDiv").css("display", "none");
	  $(".container-fluid").css("opacity", "unset");
        alert("No Records to Display");
    }

   
    $("#loaderDiv").css("display", "none");
    $(".container-fluid").css("opacity", "unset");
    $('#ShowExport').css('display', 'block');
}

function GetDataForMonthlyPassIssuanceReport2(PassType, reportType, fromDate, toDate) {
    $(".container-fluid").css("opacity", 0.2);
    $("#loaderDiv").css("display", "block");
    $("#btnSearch").attr("disabled", "disabled");

    var passtype = PassType;
    var reporttype = reportType;
    var fromDate = fromDate;
    var toDate = toDate;
    var data = { fromDate: fromDate, toDate: toDate, PassType: passtype, reportType: reporttype };

    var x = "TollApi.aspx/";
    var y = "GetDataForMonthlyPassIssuanceReport2";
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: x + y,
        data: "{'fromDate': '" + fromDate + "','toDate': '" + toDate + "','PassType': '" + passtype + "','reportType': '" + reporttype + "'}",
        dataType: "json",
        success: SuccesGetDataForMonthlyPassReport,
        error: ErrorResponse
    });
}


function SuccesGetDataForMonthlyPassReport(data, status) {
    
    var objTransactionReportData = JSON.parse(data.d);
//alert(objTransactionReportData );
    var TransactionReportData = '';
    console.log(data.d);
if (objTransactionReportData.length > 0) {
    var my_columns = [];

    $.each(objTransactionReportData[0], function (key, value) {
        var my_item = {};
        my_item.data = key;
        my_item.title = key;
        my_columns.push(my_item);
    });
 $("#grdiDiv").css("display", "block");
    var CreditSettlementReport = '';
    CreditSettlementReport += ' <table id="tblTransactionReport1" class="display nowrap dataTable dtr-inline" cellspacing="0" role="grid"  style="border: 1px solid black"  width="100%"></table>';
    $('#dvHTML').html(CreditSettlementReport);
    $('#tblTransactionReport1').DataTable(
            {
                
                "lengthMenu": [[15, 25, 50, -1], [15, 25, 50, "All"]],
                "scrollY": 400,
                "scrollX": true,
                data: objTransactionReportData,
                "columns": my_columns

            });

}
    else {
  $("#loaderDiv").css("display", "none");
	  $(".container-fluid").css("opacity", "unset");
        alert("No Records to Display");
    }

   
    $("#loaderDiv").css("display", "none");
    $(".container-fluid").css("opacity", "unset");    
    $('#ContentPlaceHolder1_lbtnExport').css('display', 'block');
    $('#ContentPlaceHolder1_lbtnPDF').css('display', 'block');

}


function SuccesGetDataForMonthlyPassActive(data, status) {
    
    var objTransactionReportData = JSON.parse(data.d);
    var TransactionReportData = '';
    console.log(data.d);
	if (objTransactionReportData.length > 0) {
    var my_columns = [];

    $.each(objTransactionReportData[0], function (key, value) {
        var my_item = {};
        my_item.data = key;
        my_item.title = key;
        my_columns.push(my_item);
    });
	 $("#gdActive").css("display", "block");
    var CreditSettlementReport = '';
    CreditSettlementReport += ' <table id="tblTransactionReport2" class="display nowrap dataTable dtr-inline" cellspacing="0" role="grid"  style="border: 1px solid black"  width="100%"></table>';
    $('#dvHTMLActive').html(CreditSettlementReport);
    $('#tblTransactionReport2').DataTable(
            {
                
                "lengthMenu": [[15, 25, 50, -1], [15, 25, 50, "All"]],
                "scrollY": 400,
                "scrollX": true,
                data: objTransactionReportData,
                "columns": my_columns

            });

}
    else {
 	  $("#loaderDiv").css("display", "none");
	  $(".container-fluid").css("opacity", "unset");
         alert("No Records to Display");
    }

   
    $("#loaderDiv").css("display", "none");
    $(".container-fluid").css("opacity", "unset");
	$("#btnSearch").removeAttr("disabled");    
  

}

function SuccesGetDataForLocalPassReport(data, status) {

    var objTransactionReportData = JSON.parse(data.d);
    var TransactionReportData = '';
    console.log(data.d);
    if (objTransactionReportData.length > 0) {
        var my_columns = [];

        $.each(objTransactionReportData[0], function (key, value) {
            var my_item = {};
            my_item.data = key;
            my_item.title = key;
            my_columns.push(my_item);
        });
        $("#gdActive").css("display", "block");
        var CreditSettlementReport = '';
        CreditSettlementReport += ' <table id="tblLocalPassReport" class="display nowrap dataTable dtr-inline" cellspacing="0" role="grid"  style="border: 1px solid black"  width="100%"></table>';
        $('#dvHTMLActive').html(CreditSettlementReport);
        $('#tblLocalPassReport').DataTable(
            {

                "lengthMenu": [[15, 25, 50, -1], [15, 25, 50, "All"]],
                "scrollY": 400,
                "scrollX": true,
                data: objTransactionReportData,
                "columns": my_columns

            });

    }
    else {
        $("#loaderDiv").css("display", "none");
        $(".container-fluid").css("opacity", "unset");
        $("#gdActive").css("display", "none");
        alert("No Records to Display");
    }


    $("#loaderDiv").css("display", "none");
    $(".container-fluid").css("opacity", "unset");
    $("#btnSearch").removeAttr("disabled");


}


function SuccesGetDataForVRCTransactionReport(data, status) {

    var objVRCTransactionReportData = JSON.parse(data.d);
    var VRCTransactionReportData = '';
    console.log(data);
    if (objVRCTransactionReportData.length > 0) {
        VRCTransactionReportData += '<table id="tblTransactionReport" class="display nowrap dataTable dtr-inline" cellspacing="0" role="grid" aria-describedby="example_info" style="border:1px solid black">';
        VRCTransactionReportData += '<thead>';
        VRCTransactionReportData += '<tr role="row">';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Action</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">CCH Txn ID</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Agency Txn ID</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Txn Date</th>';
        // VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Txn Amount</th>';
        //VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Processed Date</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Accepted Amount(Rs.)</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Licence Plate No</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">AVC Amount(Rs.)</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Actual Vehical Class</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Vehicle Class Compare</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Tag Class</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Mapper Class</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Tag Serial No.</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Status</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Journey Type</th>';
        // VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Response Description </th>';
        // VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Settle Date </th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Is Image Uploaded</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;">Image wide Range</th>';
        VRCTransactionReportData += '<th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 136px;"> Image Rear View</th>';
        VRCTransactionReportData += '</tr>';
        VRCTransactionReportData += '</thead>';
        VRCTransactionReportData += '<tbody>';
        for (var i = 0; i < objVRCTransactionReportData.length; i++) {
            VRCTransactionReportData += '<tr role="row" class="odd">';
            VRCTransactionReportData += '<td class="sorting_1"><linkbutton id="appBtn"><img src="images/icon/Approve.png" onclick="DynamicAcceptClick()" style="height:1rem; margin-right: 16px;" title="Approve" alt="Approve" /></linkbutton><linkbutton id="rejBtn"  onclick="DynamicRejectDiv()" ><img src="images/icon/Reject.png" style="height:1rem" title="Reject" alt="Reject" /></linkbutton></td>';
           VRCTransactionReportData += '<td >' + objVRCTransactionReportData[i].file_txn_id + '</td>';
           // VRCTransactionReportData += '<td class="sorting_1">' + objVRCTransactionReportData[i].file_txn_id + '</td>';
            VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].txn_id + '</td>';
            VRCTransactionReportData += '<td >' + objVRCTransactionReportData[i].conn_txn_time + '</td>';

            // VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].tran_amount + '</td>';
            // VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].req_in + '</td>';
            VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].acc_amount + '</td>';
            VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].vehicle_reg_no + '</td>';
            VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].AVC_Amount + '</td>';
            VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].avc + '</td>';
            VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].mvcavc + '</td>';
            VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].Tag_Class + '</td>';
            VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].Mapper_Class + '</td>';

            VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].vehicle_tag_id + '</td>';
            VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].tran_status + '</td>'; /// <reference path="../Images/front.jpg" />

            VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].journey_type + '</td>';
            // VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].RSPC_Desc + '</td>';
            //  VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].settleDate + '</td>';
            VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].is_image_uploaded + '</td>';
            // VRCTransactionReportData += '<td>' + objVRCTransactionReportData[i].img_wide_range + '</td>';
            VRCTransactionReportData += '<td style="cursor:pointer; color:blue;"><linkbutton id="myBtn" onclick="DynamicDiv(this.innerHTML)">' + objVRCTransactionReportData[i].img_wide_range + '</linkbutton></td>';
            VRCTransactionReportData += '<td style="cursor:pointer; color:blue"><linkbutton id="myBtn" onclick="DynamicDiv(this.innerHTML)">' + objVRCTransactionReportData[i].img_rear_view + '</linkbutton></td>';
            //// VRCTransactionReportData += '<td style="cursor:pointer;">' + '<img src="Images/front.jpg" style="width:65px; height:60px;">' + '</td>';
            // VRCTransactionReportData += '<td style="cursor:pointer;"><linkbutton id="myBtn" onclick="DynamicDiv()">' + objVRCTransactionReportData[i].img_rear_view + '</linkbutton></td>';
            VRCTransactionReportData += '</tr>';
        }
        VRCTransactionReportData += '</tbody>';
        VRCTransactionReportData += '</table>';
        $('#dvHTML').html(VRCTransactionReportData);
        $('#tblTransactionReport').DataTable(
            {
//                dom: 'Bfrtip',
//                     buttons: [
//                 'csv', 'excel', 'pdf'
//                   ],
               "lengthMenu": [[15, 25, 50, -1], [15, 25, 50, "All"]],
                "scrollY": 400,
                "scrollX": true
               // data: objTransactionReportData,
	        //     "columns": my_columns

	         });
	         
	  $("#grdiDiv").css("display", "block");
	  $("#loaderDiv").css("display", "none");
	  $(".container-fluid").css("opacity", "unset");	  
      $("#btnSearch").removeAttr("disabled");
      $('#btnSearch').val('Search');
      $('#ShowExport').css('display', 'block');
}
    else {
  $("#loaderDiv").css("display", "none");
	  $(".container-fluid").css("opacity", "unset");
        alert("No Records to Display");
    }
    $("#btnSearch").removeAttr("disabled");
    $('#btnSearch').val('Search');
}


function DynamicDiv(Img) {

    //debugger;  

    var iDiv = document.createElement('div');
    iDiv.id = 'myModal';
    iDiv.className = 'modal';

    // Now create and append to iDiv
    var innerDiv = document.createElement('div');
    innerDiv.className = 'modal-content';

    innerDiv.innerHTML = '<img id="img1" src="Report.aspx?FileName=/' + Img + '" style="width:95%;"><span class="close" id="abc" onclick="closed()" >&times;</span>';

    // The variable iDiv is still good... Just append to it.
    iDiv.appendChild(innerDiv);
    // Then append the whole thing onto the body
    document.getElementsByTagName('body')[0].appendChild(iDiv);
    var modal = document.getElementById('myModal');
    modal.style.display = "block";
    //var mm = document.getElementById('img1');
    //mm.src="SFTP_ROLL_IMAGES/"+Img+"";
    document.getElementById('img1').src = "Report.aspx?FileName=/" + Img + "";


}
function DynamicAcceptClick() {


}

function DynamicRejectDiv() {
    //https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input/file
    //alert($(this).closest('tr').index());
    //alert(this.parentNode.parentNode.rowIndex)
   // alert($(this).closest('td').parent()[0].sectionRowIndex);
    var $item = $(this).closest("tr")   // Finds the closest row <tr> 
        .find(".nr")     // Gets a descendent with class="nr"
        ;         // Retrieves the text within <td>
    alert(($item));

    //debugger;  

    var iDiv = document.createElement('div');
    iDiv.id = 'myModal';
    iDiv.className = 'modal';
    iDiv.style = 'width:60%';

    // Now create and append to iDiv
    var innerDiv = document.createElement('div');
    innerDiv.className = 'modal-content';
    innerDiv.innerHTML = '<div class="modal-header"><h4 class="modal-title">Rejection Reason</h4><span class="close"  id="abc" onclick="closed()" >&times;</span> </div >';

    innerDiv.innerHTML += '<TextArea id="txtreject" placeholder="Comments" class="form-control" style="width:45%; height=45px;"></TextArea>';
    innerDiv.innerHTML += '<div><label for="file">Choose file to upload</label><input type="file" id="file" name="file" multiple></div>';
   // innerDiv.innerHTML += '<button type="button" id="browseBtn" class="btn btn-primary" style="width:100px";>Browse</button>';
    innerDiv.innerHTML += '<asp:FileUpload ID="FUUpload" runat="server" Width="271px" />';

    innerDiv.innerHTML += '<button type="submit" class="btn btn-primary" style="width:100px";>Submit</button>';


    // The variable iDiv is still good... Just append to it.
    iDiv.appendChild(innerDiv);
    // Then append the whole thing onto the body
    document.getElementsByTagName('body')[0].appendChild(iDiv);
    var modal = document.getElementById('myModal');
    modal.style.display = "block";
    //var mm = document.getElementById('img1');
    //mm.src="SFTP_ROLL_IMAGES/"+Img+"";
    //document.getElementById('img1').src = "Report.aspx?FileName=/" + Img + "";


}

function closed() {
    //debugger;
    var modal = document.getElementById('myModal');
    modal.style.display = "none";
    document.getElementById('img1').src = "#";
    //$('#img1').remove();

}



  